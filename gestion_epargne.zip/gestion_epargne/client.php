<?php

error_reporting(E_ALL);
ini_set("display_errors", "1");

require_once __DIR__ . "/config/bootstrap.php";
require_once __DIR__ . "/class/Client.php";

requireLogin();

$clientModel = new Client($db);

$message = "";
$typeMessage = "";

/*
|--------------------------------------------------------------------------
| TRAITEMENT DES FORMULAIRES
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";

    /*
    |--------------------------------------------------------------------------
    | AJOUTER
    |--------------------------------------------------------------------------
    */

    if ($action === "ajouter") {

        $nom = trim($_POST["nom"] ?? "");
        $postnom = trim($_POST["postnom"] ?? "");
        $prenom = trim($_POST["prenom"] ?? "");
        $telephone = trim($_POST["telephone"] ?? "");
        $adresse = trim($_POST["adresse"] ?? "");
        $activite = trim($_POST["activite"] ?? "");

        if (
            $nom === "" ||
            $postnom === "" ||
            $prenom === "" ||
            $telephone === ""
        ) {

            $message = "Veuillez remplir tous les champs obligatoires.";
            $typeMessage = "error";

        } else {

            try {

                /*
                | Numéro client automatique
                */
                $numero = "CL-" . date("YmdHis") . rand(100, 999);

                $clientModel->ajouter(
                    $numero,
                    $nom,
                    $postnom,
                    $prenom,
                    $telephone,
                    $adresse,
                    $activite
                );

                $message = "Client ajouté avec succès.";
                $typeMessage = "success";

            } catch (PDOException $e) {

                $message = "Erreur lors de l'ajout du client.";
                $typeMessage = "error";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | MODIFIER
    |--------------------------------------------------------------------------
    */

    if ($action === "modifier") {

        $id = (int) ($_POST["id"] ?? 0);

        $nom = trim($_POST["nom"] ?? "");
        $postnom = trim($_POST["postnom"] ?? "");
        $prenom = trim($_POST["prenom"] ?? "");
        $telephone = trim($_POST["telephone"] ?? "");
        $adresse = trim($_POST["adresse"] ?? "");
        $activite = trim($_POST["activite"] ?? "");

        if ($id <= 0) {

            $message = "Client invalide.";
            $typeMessage = "error";

        } elseif (
            $nom === "" ||
            $postnom === "" ||
            $prenom === "" ||
            $telephone === ""
        ) {

            $message = "Veuillez remplir tous les champs obligatoires.";
            $typeMessage = "error";

        } else {

            try {

                $clientModel->modifier(
                    $id,
                    $nom,
                    $postnom,
                    $prenom,
                    $telephone,
                    $adresse,
                    $activite
                );

                $message = "Client modifié avec succès.";
                $typeMessage = "success";

            } catch (PDOException $e) {

                $message = "Erreur lors de la modification.";
                $typeMessage = "error";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | SUPPRIMER
    |--------------------------------------------------------------------------
    */

    if ($action === "supprimer") {

        $id = (int) ($_POST["id"] ?? 0);

        if ($id > 0) {

            try {

                $clientModel->supprimer($id);

                $message = "Client supprimé avec succès.";
                $typeMessage = "success";

            } catch (PDOException $e) {

                $message = "Impossible de supprimer ce client. Il peut être lié à un compte ou à une opération.";
                $typeMessage = "error";
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| CLIENT À MODIFIER
|--------------------------------------------------------------------------
*/

$clientModification = null;

if (isset($_GET["modifier"])) {

    $idModification = (int) $_GET["modifier"];

    if ($idModification > 0) {
        $clientModification =
            $clientModel->trouver($idModification);
    }
}


/*
|--------------------------------------------------------------------------
| RECHERCHE
|--------------------------------------------------------------------------
*/

$recherche = trim($_GET["recherche"] ?? "");

if ($recherche !== "") {

    $clients = $clientModel->rechercher($recherche);

} else {

    $clients = $clientModel->tous();
}


/*
|--------------------------------------------------------------------------
| AFFICHAGE
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/layout/header.php";

?>

<style>

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.page-header h1 {
    margin: 0;
    font-size: 26px;
}

.page-header p {
    margin: 7px 0 0;
    color: #777;
}


/* MESSAGE */

.alert {
    padding: 14px 18px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 14px;
}

.alert-success {
    background: #d1e7dd;
    color: #0f5132;
    border: 1px solid #badbcc;
}

.alert-error {
    background: #f8d7da;
    color: #842029;
    border: 1px solid #f5c2c7;
}


/* FORMULAIRE */

.form-card {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.06);
    margin-bottom: 25px;
}

.form-card h2 {
    margin-top: 0;
    margin-bottom: 20px;
    font-size: 20px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.form-group.full {
    grid-column: 1 / -1;
}

.form-group label {
    margin-bottom: 7px;
    font-size: 14px;
    font-weight: bold;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 7px;
    font-size: 14px;
    outline: none;
}

.form-group input:focus,
.form-group textarea:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 3px rgba(13,110,253,0.10);
}

.form-group textarea {
    resize: vertical;
    min-height: 80px;
}

.form-actions {
    margin-top: 20px;
    display: flex;
    gap: 10px;
}


/* BOUTONS */

.btn {
    display: inline-block;
    padding: 10px 15px;
    border: none;
    border-radius: 7px;
    text-decoration: none;
    cursor: pointer;
    font-size: 13px;
    font-weight: bold;
}

.btn-primary {
    background: #0d6efd;
    color: white;
}

.btn-primary:hover {
    background: #0b5ed7;
}

.btn-warning {
    background: #ffc107;
    color: #212529;
}

.btn-danger {
    background: #dc3545;
    color: white;
}

.btn-secondary {
    background: #6c757d;
    color: white;
}


/* RECHERCHE */

.search-card {
    background: white;
    padding: 18px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.06);
}

.search-form {
    display: flex;
    gap: 10px;
}

.search-form input {
    flex: 1;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 7px;
}


/* TABLEAU */

.table-card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.06);
    overflow-x: auto;
}

.table-card h2 {
    margin-top: 0;
    font-size: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table th {
    background: #f4f6f9;
    padding: 13px;
    text-align: left;
    font-size: 13px;
}

table td {
    padding: 13px;
    border-bottom: 1px solid #eee;
    font-size: 13px;
}

table tr:hover {
    background: #fafafa;
}

.actions {
    display: flex;
    gap: 6px;
    align-items: center;
}

.actions form {
    margin: 0;
}

.empty {
    text-align: center;
    padding: 30px;
    color: #777;
}


/* RESPONSIVE */

@media (max-width: 800px) {

    .form-grid {
        grid-template-columns: 1fr;
    }

    .form-group.full {
        grid-column: auto;
    }

    .page-header {
        display: block;
    }

    .page-header .btn {
        margin-top: 15px;
    }
}

</style>


<!-- TITRE -->

<div class="page-header">

    <div>

        <h1>
            👥 Gestion des clients
        </h1>

        <p>
            Ajouter, modifier, rechercher et gérer vos clients.
        </p>

    </div>

</div>


<!-- MESSAGE -->

<?php if ($message !== ""): ?>

    <div class="alert <?= $typeMessage === "success" ? "alert-success" : "alert-error" ?>">

        <?= e($message) ?>

    </div>

<?php endif; ?>


<!-- FORMULAIRE AJOUT / MODIFICATION -->

<div class="form-card">

    <?php if ($clientModification): ?>

        <h2>
            ✏️ Modifier le client
        </h2>

        <form method="POST" action="client.php">

            <input
                type="hidden"
                name="action"
                value="modifier"
            >

            <input
                type="hidden"
                name="id"
                value="<?= (int) $clientModification["id"] ?>"
            >

            <div class="form-grid">

                <div class="form-group">

                    <label>Nom *</label>

                    <input
                        type="text"
                        name="nom"
                        value="<?= e($clientModification["nom"]) ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Postnom *</label>

                    <input
                        type="text"
                        name="postnom"
                        value="<?= e($clientModification["postnom"]) ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Prénom *</label>

                    <input
                        type="text"
                        name="prenom"
                        value="<?= e($clientModification["prenom"]) ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Téléphone *</label>

                    <input
                        type="text"
                        name="telephone"
                        value="<?= e($clientModification["telephone"]) ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Activité</label>

                    <input
                        type="text"
                        name="activite"
                        value="<?= e($clientModification["activite"]) ?>"
                    >

                </div>


                <div class="form-group">

                    <label>Adresse</label>

                    <input
                        type="text"
                        name="adresse"
                        value="<?= e($clientModification["adresse"]) ?>"
                    >

                </div>

            </div>


            <div class="form-actions">

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    💾 Enregistrer les modifications
                </button>

                <a
                    href="client.php"
                    class="btn btn-secondary"
                >
                    Annuler
                </a>

            </div>

        </form>


    <?php else: ?>

        <h2>
            ➕ Ajouter un nouveau client
        </h2>

        <form method="POST" action="client.php">

            <input
                type="hidden"
                name="action"
                value="ajouter"
            >

            <div class="form-grid">

                <div class="form-group">

                    <label>Nom *</label>

                    <input
                        type="text"
                        name="nom"
                        placeholder="Ex : MASIKA"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Postnom *</label>

                    <input
                        type="text"
                        name="postnom"
                        placeholder="Ex : DEBORAH"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Prénom *</label>

                    <input
                        type="text"
                        name="prenom"
                        placeholder="Ex : KIVAYA"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Téléphone *</label>

                    <input
                        type="text"
                        name="telephone"
                        placeholder="Ex : 0990000000"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Activité</label>

                    <input
                        type="text"
                        name="activite"
                        placeholder="Ex : Vente de chaussures"
                    >

                </div>


                <div class="form-group">

                    <label>Adresse</label>

                    <input
                        type="text"
                        name="adresse"
                        placeholder="Ex : Beni"
                    >

                </div>

            </div>


            <div class="form-actions">

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    ➕ Enregistrer le client
                </button>

            </div>

        </form>

    <?php endif; ?>

</div>


<!-- RECHERCHE -->

<div class="search-card">

    <form
        method="GET"
        action="client.php"
        class="search-form"
    >

        <input
            type="text"
            name="recherche"
            placeholder="🔎 Rechercher par nom, téléphone, activité..."
            value="<?= e($recherche) ?>"
        >

        <button
            type="submit"
            class="btn btn-primary"
        >
            Rechercher
        </button>

        <?php if ($recherche !== ""): ?>

            <a
                href="client.php"
                class="btn btn-secondary"
            >
                Réinitialiser
            </a>

        <?php endif; ?>

    </form>

</div>


<!-- LISTE DES CLIENTS -->

<div class="table-card">

    <h2>
        📋 Liste des clients
    </h2>

    <?php if (count($clients) > 0): ?>

        <table>

            <thead>

                <tr>

                    <th>#</th>

                    <th>Numéro client</th>

                    <th>Nom complet</th>

                    <th>Téléphone</th>

                    <th>Adresse</th>

                    <th>Activité</th>

                    <th>Actions</th>

                </tr>

            </thead>


            <tbody>

            <?php foreach ($clients as $client): ?>

                <tr>

                    <td>
                        <?= (int) $client["id"] ?>
                    </td>


                    <td>
                        <strong>
                            <?= e($client["numero_client"]) ?>
                        </strong>
                    </td>


                    <td>

                        <?= e($client["nom"]) ?>

                        <?= e($client["postnom"]) ?>

                        <?= e($client["prenom"]) ?>

                    </td>


                    <td>
                        <?= e($client["telephone"]) ?>
                    </td>


                    <td>
                        <?= e($client["adresse"]) ?>
                    </td>


                    <td>
                        <?= e($client["activite"]) ?>
                    </td>


                    <td>

                        <div class="actions">

                            <a
                                href="client.php?modifier=<?= (int) $client["id"] ?>"
                                class="btn btn-warning"
                            >
                                ✏️ Modifier
                            </a>


                            <form
                                method="POST"
                                action="client.php"
                                onsubmit="return confirm('Voulez-vous vraiment supprimer ce client ?');"
                            >

                                <input
                                    type="hidden"
                                    name="action"
                                    value="supprimer"
                                >

                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= (int) $client["id"] ?>"
                                >

                                <button
                                    type="submit"
                                    class="btn btn-danger"
                                >
                                    🗑️ Supprimer
                                </button>

                            </form>

                        </div>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php else: ?>

        <div class="empty">

            <h3>
                Aucun client trouvé
            </h3>

            <p>
                Aucun client ne correspond à votre recherche.
            </p>

        </div>

    <?php endif; ?>

</div>


<?php

require_once __DIR__ . "/layout/footer.php";

?>