<?php

session_start();

$connecte = isset($_SESSION["user_id"]) && !empty($_SESSION["user_id"]);

?>

<!DOCTYPE html>
<html lang="fr">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Gestion Épargne - Accueil
</title>

<style>

/* ================================
   RESET
================================ */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family:
        Arial,
        Helvetica,
        sans-serif;

    color: #222;

    background: #f5f7fa;
}


/* ================================
   NAVBAR
================================ */

.navbar {

    position: fixed;

    top: 0;
    left: 0;

    width: 100%;

    height: 72px;

    background: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 7%;

    box-shadow:
        0 3px 15px rgba(0,0,0,0.08);

    z-index: 1000;
}

.logo {

    font-size: 21px;

    font-weight: bold;

    color: #0d6efd;

    text-decoration: none;
}

.logo span {

    color: #333;

    font-weight: normal;
}

.nav-links {

    display: flex;

    align-items: center;

    gap: 25px;
}

.nav-links a {

    text-decoration: none;

    color: #444;

    font-size: 14px;

    font-weight: 600;

    transition: 0.3s;
}

.nav-links a:hover {

    color: #0d6efd;
}

.btn-login {

    background:
        linear-gradient(
            135deg,
            #0d6efd,
            #084298
        );

    color: white !important;

    padding: 11px 20px;

    border-radius: 8px;
}


/* ================================
   HERO
================================ */

.hero {

    min-height: 680px;

    padding:
        120px 7% 70px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 50px;

    background:
        linear-gradient(
            135deg,
            #eef5ff,
            #ffffff
        );
}

.hero-content {

    flex: 1;

    max-width: 600px;
}

.hero-badge {

    display: inline-block;

    background: #dceaff;

    color: #0d6efd;

    padding: 8px 15px;

    border-radius: 30px;

    font-size: 13px;

    font-weight: bold;

    margin-bottom: 20px;
}

.hero h1 {

    font-size: 52px;

    line-height: 1.15;

    margin-bottom: 20px;

    color: #172033;
}

.hero h1 span {

    color: #0d6efd;
}

.hero p {

    font-size: 18px;

    line-height: 1.7;

    color: #667085;

    margin-bottom: 30px;
}

.hero-buttons {

    display: flex;

    gap: 15px;

    flex-wrap: wrap;
}

.btn-primary {

    display: inline-block;

    text-decoration: none;

    background:
        linear-gradient(
            135deg,
            #0d6efd,
            #084298
        );

    color: white;

    padding: 15px 25px;

    border-radius: 9px;

    font-weight: bold;

    box-shadow:
        0 7px 18px
        rgba(13,110,253,0.25);

    transition: 0.3s;
}

.btn-primary:hover {

    transform: translateY(-2px);
}

.btn-secondary {

    display: inline-block;

    text-decoration: none;

    background: white;

    color: #0d6efd;

    border: 1px solid #0d6efd;

    padding: 14px 25px;

    border-radius: 9px;

    font-weight: bold;

    transition: 0.3s;
}

.btn-secondary:hover {

    background: #0d6efd;

    color: white;
}


/* ================================
   HERO IMAGE
================================ */

.hero-image {

    flex: 1;

    max-width: 570px;

    position: relative;
}

.hero-image img {

    width: 100%;

    height: 420px;

    object-fit: cover;

    border-radius: 25px;

    box-shadow:
        0 20px 50px
        rgba(0,0,0,0.18);
}


/* ================================
   SECTION
================================ */

.section {

    padding: 80px 7%;
}

.section-title {

    text-align: center;

    margin-bottom: 50px;
}

.section-title h2 {

    font-size: 34px;

    margin-bottom: 12px;

    color: #172033;
}

.section-title p {

    color: #777;

    font-size: 16px;
}


/* ================================
   SERVICES
================================ */

.services {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 25px;
}

.service-card {

    background: white;

    padding: 30px 25px;

    border-radius: 15px;

    text-align: center;

    box-shadow:
        0 5px 20px
        rgba(0,0,0,0.06);

    transition: 0.3s;
}

.service-card:hover {

    transform:
        translateY(-7px);

    box-shadow:
        0 12px 30px
        rgba(0,0,0,0.10);
}

.service-icon {

    width: 70px;

    height: 70px;

    margin: 0 auto 20px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 50%;

    background: #eaf2ff;

    font-size: 32px;
}

.service-card h3 {

    margin-bottom: 12px;

    font-size: 18px;
}

.service-card p {

    color: #777;

    line-height: 1.6;

    font-size: 14px;
}


/* ================================
   PRESENTATION
================================ */

.about {

    display: flex;

    align-items: center;

    gap: 60px;
}

.about-image {

    flex: 1;
}

.about-image img {

    width: 100%;

    height: 380px;

    object-fit: cover;

    border-radius: 20px;

    box-shadow:
        0 12px 35px
        rgba(0,0,0,0.12);
}

.about-content {

    flex: 1;
}

.about-content h2 {

    font-size: 34px;

    margin-bottom: 20px;
}

.about-content p {

    color: #666;

    line-height: 1.8;

    margin-bottom: 20px;
}

.about-list {

    list-style: none;
}

.about-list li {

    margin-bottom: 14px;

    font-size: 15px;

    font-weight: 600;
}


/* ================================
   STATISTIQUES
================================ */

.stats-section {

    background:
        linear-gradient(
            135deg,
            #0d6efd,
            #084298
        );

    color: white;
}

.stats {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 25px;

    text-align: center;
}

.stat h3 {

    font-size: 38px;

    margin-bottom: 8px;
}

.stat p {

    opacity: 0.85;
}


/* ================================
   CTA
================================ */

.cta {

    text-align: center;

    background: white;

    padding: 70px 20px;
}

.cta h2 {

    font-size: 35px;

    margin-bottom: 15px;
}

.cta p {

    color: #777;

    margin-bottom: 30px;
}


/* ================================
   FOOTER
================================ */

.footer {

    background: #172033;

    color: white;

    padding: 30px 7%;

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;
}

.footer p {

    color: #aaa;

    font-size: 13px;
}

.footer-links {

    display: flex;

    gap: 20px;
}

.footer-links a {

    color: #ddd;

    text-decoration: none;

    font-size: 13px;
}


/* ================================
   RESPONSIVE
================================ */

@media (max-width: 1000px) {

    .services {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .stats {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .hero h1 {

        font-size: 42px;
    }
}

@media (max-width: 750px) {

    .navbar {

        padding: 0 20px;
    }

    .nav-links a:not(.btn-login) {

        display: none;
    }

    .hero {

        flex-direction: column;

        text-align: center;

        padding-top: 120px;
    }

    .hero-content {

        max-width: 100%;
    }

    .hero-buttons {

        justify-content: center;
    }

    .hero-image {

        width: 100%;
    }

    .about {

        flex-direction: column;
    }

    .services {

        grid-template-columns: 1fr;
    }

    .stats {

        grid-template-columns: 1fr;
    }

    .footer {

        flex-direction: column;

        text-align: center;
    }
}

</style>

</head>

<body>


<!-- ================================
     NAVBAR
================================ -->

<nav class="navbar">

    <a
        href="index.php"
        class="logo"
    >
        💰 GESTION
        <span>ÉPARGNE</span>
    </a>

    <div class="nav-links">

        <a href="#accueil">
            Accueil
        </a>

        <a href="#services">
            Services
        </a>

        <a href="#apropos">
            À propos
        </a>

        <?php if ($connecte): ?>

            <a
                href="dashboard.php"
                class="btn-login"
            >
                Tableau de bord
            </a>

        <?php else: ?>

            <a
                href="login.php"
                class="btn-login"
            >
                Se connecter
            </a>

        <?php endif; ?>

    </div>

</nav>


<!-- ================================
     HERO
================================ -->

<section
    class="hero"
    id="accueil"
>

    <div class="hero-content">

        <div class="hero-badge">
            ✨ Solution moderne de gestion
        </div>

        <h1>

            Gérez vos

            <span>
                épargnes
            </span>

            et vos crédits
            simplement

        </h1>

        <p>

            Une plateforme simple et efficace
            pour gérer vos clients, leurs épargnes,
            les crédits accordés et le suivi
            des remboursements.

        </p>

        <div class="hero-buttons">

            <?php if ($connecte): ?>

                <a
                    href="dashboard.php"
                    class="btn-primary"
                >
                    📊 Accéder au tableau de bord
                </a>

            <?php else: ?>

                <a
                    href="login.php"
                    class="btn-primary"
                >
                    🔐 Commencer maintenant
                </a>

            <?php endif; ?>

            <a
                href="#services"
                class="btn-secondary"
            >
                Découvrir nos services
            </a>

        </div>

    </div>


    <div class="hero-image">

        <img
            src="https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1000&q=80"
            alt="Gestion financière"
        >

    </div>

</section>


<!-- ================================
     SERVICES
================================ -->

<section
    class="section"
    id="services"
>

    <div class="section-title">

        <h2>
            Nos fonctionnalités
        </h2>

        <p>
            Tout ce dont vous avez besoin
            pour gérer votre activité.
        </p>

    </div>


    <div class="services">


        <div class="service-card">

            <div class="service-icon">
                👥
            </div>

            <h3>
                Gestion des clients
            </h3>

            <p>

                Enregistrez et gérez facilement
                les informations de vos clients.

            </p>

        </div>


        <div class="service-card">

            <div class="service-icon">
                💰
            </div>

            <h3>
                Gestion de l'épargne
            </h3>

            <p>

                Gérez les comptes d'épargne,
                les dépôts et les retraits.

            </p>

        </div>


        <div class="service-card">

            <div class="service-icon">
                💳
            </div>

            <h3>
                Gestion des crédits
            </h3>

            <p>

                Enregistrez les crédits accordés
                et suivez leur évolution.

            </p>

        </div>


        <div class="service-card">

            <div class="service-icon">
                📊
            </div>

            <h3>
                Remboursements
            </h3>

            <p>

                Suivez les remboursements
                et les montants déjà payés.

            </p>

        </div>


    </div>

</section>


<!-- ================================
     À PROPOS
================================ -->

<section
    class="section"
    id="apropos"
>

    <div class="about">


        <div class="about-image">

            <img
                src="7e6de693c128a3c3f5eaa9548cdbcfaf.jpg"
                alt="Gestion financière"
                src="13c765a109f0ec59dd7af6acf190e782.jpg"
                alt="Gestion financière"
                src="742b5ca86d1246abf998989e4e9451bb.jpg"
                alt="Gestion financière"
                src="05834708a500ce28cae5666260be2725.jpg"
                alt="Gestion financière"
            >

        </div>


        <div class="about-content">

            <h2>
                Une gestion simple et organisée
            </h2>

            <p>

                Notre plateforme permet de centraliser
                toutes les opérations liées à vos clients,
                à l'épargne et aux crédits.

            </p>

            <p>

                Grâce au tableau de bord, vous pouvez
                rapidement consulter les informations
                importantes de votre activité.

            </p>


            <ul class="about-list">

                <li>
                    ✅ Gestion centralisée des clients
                </li>

                <li>
                    ✅ Suivi des comptes d'épargne
                </li>

                <li>
                    ✅ Gestion des crédits
                </li>

                <li>
                    ✅ Suivi des remboursements
                </li>

                <li>
                    ✅ Tableau de bord avec statistiques
                </li>

            </ul>

        </div>

    </div>

</section>


<!-- ================================
     STATISTIQUES
================================ -->

<section class="section stats-section">

    <div class="stats">


        <div class="stat">

            <h3>
                100%
            </h3>

            <p>
                Gestion centralisée
            </p>

        </div>


        <div class="stat">

            <h3>
                24/7
            </h3>

            <p>
                Accès à la plateforme
            </p>

        </div>


        <div class="stat">

            <h3>
                🔐
            </h3>

            <p>
                Accès sécurisé
            </p>

        </div>


        <div class="stat">

            <h3>
                📊
            </h3>

            <p>
                Suivi en temps réel
            </p>

        </div>


    </div>

</section>


<!-- ================================
     CTA
================================ -->

<section class="cta">

    <h2>
        Prêt à commencer ?
    </h2>

    <p>

        Connectez-vous à votre espace
        de gestion pour commencer.

    </p>


    <?php if ($connecte): ?>

        <a
            href="dashboard.php"
            class="btn-primary"
        >
            📊 Ouvrir mon tableau de bord
        </a>

    <?php else: ?>

        <a
            href="login.php"
            class="btn-primary"
        >
            🔐 Se connecter
        </a>

    <?php endif; ?>

</section>


<!-- ================================
     FOOTER
================================ -->

<footer class="footer">

    <p>
        © <?= date("Y") ?>
        Gestion Épargne.
        Tous droits réservés.
    </p>

    <div class="footer-links">

        <a href="#accueil">
            Accueil
        </a>

        <a href="#services">
            Services
        </a>

        <a href="#apropos">
            À propos
        </a>

        <?php if (!$connecte): ?>

            <a href="login.php">
                Connexion
            </a>

        <?php endif; ?>

    </div>

</footer>


</body>

</html>