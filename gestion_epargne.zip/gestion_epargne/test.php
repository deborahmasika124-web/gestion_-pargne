<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

echo "<h2>TEST DE LA PLATEFORME</h2>";

require_once __DIR__ . "/config/database.php";

echo "1. database.php chargé.<br>";

$database = new Database();

echo "2. Classe Database trouvée.<br>";

$db = $database->connect();

echo "3. Connexion MySQL réussie.<br>";

$result = $db->query("SELECT DATABASE() AS nom_base");

$row = $result->fetch();

echo "4. Base utilisée : <strong>";
echo htmlspecialchars($row["nom_base"]);
echo "</strong><br>";

echo "<br><strong>Tout fonctionne correctement !</strong>";