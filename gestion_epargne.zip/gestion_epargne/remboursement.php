<?php

require_once __DIR__ . "/config/bootstrap.php";

requireLogin();

/*
|--------------------------------------------------------------------------
| Message
|--------------------------------------------------------------------------
*/

$message = "";
$typeMessage = "";


/*
|--------------------------------------------------------------------------
| ENREGISTRER UN REMBOURSEMENT
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";

    if ($action === "rembourser") {

        $creditId = (int) ($_POST["credit_id"] ?? 0);
        $montant = (float) ($_POST["montant"] ?? 0);
        $observation = trim($_POST["observation"] ?? "");

        if ($creditId <= 0) {

            $message = "Crédit invalide.";
            $typeMessage = "error";

        } elseif ($montant <= 0) {

            $message = "Le montant du remboursement doit être supérieur à 0.";
            $typeMessage = "error";

        } else {

            try {

                $db->beginTransaction();

                /*
                |--------------------------------------------------------------------------
                | Récupérer le crédit
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    SELECT
                        id,
                        client_id,
                        montant,
                        taux,
                        duree,
                        montant_total,
                        montant_rembourse,
                        solde_restant,
                        statut
                    FROM credits
                    WHERE id = ?
                    LIMIT 1
                    FOR UPDATE
                ");

                $stmt->execute([$creditId]);

                $credit = $stmt->fetch(PDO::FETCH_ASSOC);


                if (!$credit) {

                    throw new Exception(
                        "Le crédit demandé n'existe pas."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Vérifier le statut
                |--------------------------------------------------------------------------
                */

                if (
                    $credit["statut"] !== "approuve"
                    &&
                    $credit["statut"] !== "en_cours"
                ) {

                    throw new Exception(
                        "Ce crédit ne peut pas recevoir de remboursement."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Solde restant AVANT remboursement
                |--------------------------------------------------------------------------
                */

                $soldeAvant = (float) $credit["solde_restant"];


                if ($soldeAvant <= 0) {

                    throw new Exception(
                        "Ce crédit est déjà entièrement remboursé."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Empêcher un remboursement supérieur au solde
                |--------------------------------------------------------------------------
                */

                if ($montant > $soldeAvant) {

                    throw new Exception(
                        "Le remboursement ne peut pas dépasser le solde restant de "
                        . number_format(
                            $soldeAvant,
                            2,
                            ",",
                            " "
                        )
                        . " $."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Nouveau total remboursé
                |--------------------------------------------------------------------------
                */

                $montantRembourseAvant =
                    (float) $credit["montant_rembourse"];

                $nouveauMontantRembourse =
                    $montantRembourseAvant + $montant;


                /*
                |--------------------------------------------------------------------------
                | Nouveau solde restant
                |--------------------------------------------------------------------------
                */

                $nouveauSolde =
                    $soldeAvant - $montant;


                /*
                |--------------------------------------------------------------------------
                | Éviter une petite valeur négative
                |--------------------------------------------------------------------------
                */

                if (abs($nouveauSolde) < 0.000001) {
                    $nouveauSolde = 0;
                }


                /*
                |--------------------------------------------------------------------------
                | Nouveau statut
                |--------------------------------------------------------------------------
                */

                if ($nouveauSolde <= 0) {

                    $nouveauSolde = 0;

                    $nouveauStatut = "termine";

                } else {

                    $nouveauStatut = "en_cours";
                }


                /*
                |--------------------------------------------------------------------------
                | Enregistrer le remboursement
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    INSERT INTO remboursements
                    (
                        credit_id,
                        montant,
                        date_remboursement,
                        observation,
                        user_id
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        NOW(),
                        ?,
                        ?
                    )
                ");

                $stmt->execute([
                    $creditId,
                    $montant,
                    $observation,
                    $_SESSION["user_id"]
                ]);


                /*
                |--------------------------------------------------------------------------
                | Mettre à jour le crédit
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    UPDATE credits
                    SET
                        montant_rembourse = ?,
                        solde_restant = ?,
                        statut = ?
                    WHERE id = ?
                ");

                $stmt->execute([
                    $nouveauMontantRembourse,
                    $nouveauSolde,
                    $nouveauStatut,
                    $creditId
                ]);


                /*
                |--------------------------------------------------------------------------
                | Valider la transaction
                |--------------------------------------------------------------------------
                */

                $db->commit();


                /*
                |--------------------------------------------------------------------------
                | Message de succès
                |--------------------------------------------------------------------------
                */

                $message =
                    "Remboursement effectué avec succès : "
                    . number_format(
                        $montant,
                        2,
                        ",",
                        " "
                    )
                    . " $. "
                    . "Reste à rembourser : "
                    . number_format(
                        $nouveauSolde,
                        2,
                        ",",
                        " "
                    )
                    . " $.";


                if ($nouveauSolde <= 0) {

                    $message .= " Crédit entièrement remboursé.";

                }

                $typeMessage = "success";


            } catch (Throwable $e) {

                if ($db->inTransaction()) {
                    $db->rollBack();
                }

                $message = $e->getMessage();
                $typeMessage = "error";
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| RÉCUPÉRER LES CRÉDITS EN COURS
|--------------------------------------------------------------------------
*/

$stmt = $db->query("
    SELECT
        cr.id,
        cr.client_id,
        cr.montant,
        cr.taux,
        cr.duree,
        cr.montant_total,
        cr.montant_rembourse,
        cr.solde_restant,
        cr.date_demande,
        cr.date_decaissement,
        cr.statut,

        c.nom,
        c.postnom,
        c.prenom,
        c.telephone

    FROM credits cr

    INNER JOIN clients c
        ON c.id = cr.client_id

    WHERE cr.statut IN ('approuve', 'en_cours')

    ORDER BY cr.id DESC
");

$credits = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| DERNIERS REMBOURSEMENTS
|--------------------------------------------------------------------------
*/

$stmt = $db->query("
    SELECT
        r.id,
        r.credit_id,
        r.montant,
        r.date_remboursement,
        r.observation,

        cr.montant_total,
        cr.montant_rembourse,
        cr.solde_restant,
        cr.statut,

        c.nom,
        c.postnom,
        c.prenom

    FROM remboursements r

    INNER JOIN credits cr
        ON cr.id = r.credit_id

    INNER JOIN clients c
        ON c.id = cr.client_id

    ORDER BY r.id DESC

    LIMIT 20
");

$remboursements = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| STATISTIQUES
|--------------------------------------------------------------------------
*/

$stmt = $db->query("
    SELECT
        COUNT(*) AS nombre_credits,
        COALESCE(SUM(montant), 0) AS total_credits,
        COALESCE(SUM(montant_rembourse), 0) AS total_rembourse,
        COALESCE(SUM(solde_restant), 0) AS total_restant

    FROM credits

    WHERE statut IN ('approuve', 'en_cours')
");

$stats = $stmt->fetch(PDO::FETCH_ASSOC);

$nombreCredits = (int) ($stats["nombre_credits"] ?? 0);
$totalCredits = (float) ($stats["total_credits"] ?? 0);
$totalRembourse = (float) ($stats["total_rembourse"] ?? 0);
$totalRestant = (float) ($stats["total_restant"] ?? 0);

?>

<!DOCTYPE html>

<html lang="fr">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Remboursements - Gestion Épargne</title>


<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background: #f4f6f9;

    color: #333;
}


/* HEADER */

.topbar {

    height: 70px;

    background:
        linear-gradient(
            135deg,
            #0d6efd,
            #084298
        );

    color: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 3px 12px
        rgba(0,0,0,0.15);
}


.logo {

    font-size: 21px;

    font-weight: bold;
}


.logo span {

    font-weight: normal;

    opacity: 0.85;
}


.user-info {

    font-size: 14px;

    background:
        rgba(255,255,255,0.15);

    padding: 9px 16px;

    border-radius: 25px;
}


/* LAYOUT */

.layout {

    display: flex;

    min-height:
        calc(100vh - 70px);
}


/* SIDEBAR */

.sidebar {

    width: 240px;

    background: #212529;

    padding: 22px 12px;

    box-shadow:
        3px 0 10px
        rgba(0,0,0,0.08);
}


.menu-title {

    color: #8c98a4;

    font-size: 11px;

    text-transform: uppercase;

    letter-spacing: 1px;

    padding: 10px 15px;

    margin-bottom: 8px;
}


.sidebar a {

    display: block;

    color: #ddd;

    text-decoration: none;

    padding: 14px 15px;

    margin-bottom: 6px;

    border-radius: 8px;

    font-size: 15px;

    transition: 0.2s;
}


.sidebar a:hover {

    background: #343a40;

    color: white;

    transform:
        translateX(3px);
}


.sidebar a.active {

    background:
        linear-gradient(
            135deg,
            #0d6efd,
            #0b5ed7
        );

    color: white;
}


.logout {

    margin-top: 30px;

    padding-top: 15px;

    border-top:
        1px solid #343a40;
}


.logout a {

    color: #ffb3b3;
}


/* MAIN */

.main {

    flex: 1;

    padding: 30px;

    min-width: 0;
}


.page-title {

    margin-top: 0;

    margin-bottom: 25px;

    font-size: 27px;
}


/* MESSAGE */

.message {

    padding: 15px 18px;

    border-radius: 8px;

    margin-bottom: 20px;

    font-size: 14px;

    font-weight: bold;
}


.message.success {

    background: #d1e7dd;

    color: #0f5132;

    border:
        1px solid #badbcc;
}


.message.error {

    background: #f8d7da;

    color: #842029;

    border:
        1px solid #f5c2c7;
}


/* STATISTIQUES */

.stats {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 25px;
}


.stat {

    background: white;

    border-radius: 12px;

    padding: 22px;

    box-shadow:
        0 3px 12px
        rgba(0,0,0,0.06);
}


.stat-title {

    color: #777;

    font-size: 13px;

    margin-bottom: 8px;
}


.stat-value {

    color: #0d6efd;

    font-size: 23px;

    font-weight: bold;
}


/* CARD */

.card {

    background: white;

    border-radius: 12px;

    padding: 25px;

    margin-bottom: 25px;

    box-shadow:
        0 3px 12px
        rgba(0,0,0,0.06);
}


.card h2 {

    margin-top: 0;

    margin-bottom: 20px;

    font-size: 20px;
}


/* FORM */

.form-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;
}


.form-group {

    margin-bottom: 15px;
}


.form-group label {

    display: block;

    font-size: 14px;

    font-weight: bold;

    margin-bottom: 7px;
}


.form-group input,
.form-group select,
.form-group textarea {

    width: 100%;

    padding: 12px;

    border:
        1px solid #ddd;

    border-radius: 7px;

    font-size: 14px;

    outline: none;
}


.form-group textarea {

    resize: vertical;

    min-height: 80px;
}


.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #0d6efd;

    box-shadow:
        0 0 0 3px
        rgba(13,110,253,0.10);
}


/* BOUTON */

.btn {

    border: none;

    cursor: pointer;

    padding: 12px 18px;

    border-radius: 7px;

    font-weight: bold;

    font-size: 14px;
}


.btn-primary {

    background: #0d6efd;

    color: white;
}


.btn-primary:hover {

    background: #0b5ed7;
}


/* TABLE */

.table-container {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 900px;
}


th {

    background: #f1f3f5;

    text-align: left;

    padding: 13px;

    font-size: 13px;
}


td {

    padding: 13px;

    border-bottom:
        1px solid #e9ecef;

    font-size: 14px;
}


.amount {

    font-weight: bold;

    color: #0d6efd;
}


.remaining {

    font-weight: bold;

    color: #dc3545;
}


.remaining.zero {

    color: #198754;
}


.badge {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: bold;
}


.badge-en-cours {

    background: #fff3cd;

    color: #664d03;
}


.badge-termine {

    background: #d1e7dd;

    color: #0f5132;
}


/* RESPONSIVE */

@media (max-width: 1000px) {

    .stats {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .form-grid {

        grid-template-columns:
            1fr 1fr;
    }
}


@media (max-width: 700px) {

    .layout {

        flex-direction: column;
    }

    .sidebar {

        width: 100%;
    }

    .main {

        padding: 15px;
    }

    .stats {

        grid-template-columns: 1fr;
    }

    .form-grid {

        grid-template-columns: 1fr;
    }

    .topbar {

        padding: 0 15px;
    }
}

</style>

</head>


<body>


<!-- TOPBAR -->

<div class="topbar">

    <div class="logo">

        GESTION ÉPARGNE

        <span>| Administration</span>

    </div>


    <div class="user-info">

        👤

        <?= e($_SESSION["user_nom"] ?? "Administrateur") ?>

    </div>

</div>


<div class="layout">


<!-- SIDEBAR -->

<aside class="sidebar">

    <div class="menu-title">
        Navigation
    </div>


    <a href="dashboard.php">
        🏠 Tableau de bord
    </a>


    <a href="client.php">
        👥 Clients
    </a>


    <a href="epargne.php">
        💰 Épargne
    </a>


    <a href="credits.php">
        💳 Crédits
    </a>


    <a
        href="remboursement.php"
        class="active"
    >
        💵 Remboursements
    </a>


    <a href="transactions.php">
        📊 Transactions
    </a>


    <div class="logout">

        <a href="logout.php">
            🚪 Déconnexion
        </a>

    </div>

</aside>


<!-- CONTENU -->

<main class="main">


<h1 class="page-title">
    💵 Gestion des remboursements
</h1>


<?php if ($message !== ""): ?>

    <div class="message <?= e($typeMessage) ?>">

        <?= e($message) ?>

    </div>

<?php endif; ?>


<!-- STATISTIQUES -->

<div class="stats">


    <div class="stat">

        <div class="stat-title">
            Crédits en cours
        </div>

        <div class="stat-value">
            <?= $nombreCredits ?>
        </div>

    </div>


    <div class="stat">

        <div class="stat-title">
            Total des crédits
        </div>

        <div class="stat-value">

            <?= number_format(
                $totalCredits,
                2,
                ",",
                " "
            ) ?>

            $

        </div>

    </div>


    <div class="stat">

        <div class="stat-title">
            Total remboursé
        </div>

        <div class="stat-value">

            <?= number_format(
                $totalRembourse,
                2,
                ",",
                " "
            ) ?>

            $

        </div>

    </div>


    <div class="stat">

        <div class="stat-title">
            Total restant
        </div>

        <div class="stat-value">

            <?= number_format(
                $totalRestant,
                2,
                ",",
                " "
            ) ?>

            $

        </div>

    </div>

</div>


<!-- REMBOURSEMENT -->

<div class="card">

    <h2>
        ➕ Effectuer un remboursement
    </h2>


    <form
        method="POST"
        action="remboursement.php"
    >

        <input
            type="hidden"
            name="action"
            value="rembourser"
        >


        <div class="form-grid">


            <div class="form-group">

                <label for="credit_id">
                    Crédit
                </label>


                <select
                    name="credit_id"
                    id="credit_id"
                    required
                >

                    <option value="">
                        -- Sélectionner un crédit --
                    </option>


                    <?php foreach ($credits as $credit): ?>

                        <option
                            value="<?= (int) $credit["id"] ?>"
                        >

                            <?= e(
                                $credit["nom"]
                                . " "
                                . $credit["postnom"]
                                . " "
                                . $credit["prenom"]
                            ) ?>

                            -

                            Crédit
                            <?= number_format(
                                (float) $credit["montant_total"],
                                2,
                                ",",
                                " "
                            ) ?>

                            $

                            -

                            Reste
                            <?= number_format(
                                (float) $credit["solde_restant"],
                                2,
                                ",",
                                " "
                            ) ?>

                            $

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="form-group">

                <label for="montant">

                    Montant du remboursement

                </label>


                <input
                    type="number"
                    name="montant"
                    id="montant"
                    min="0.01"
                    step="0.01"
                    placeholder="Exemple : 10000"
                    required
                >

            </div>


            <div class="form-group">

                <label for="observation">

                    Observation

                </label>


                <input
                    type="text"
                    name="observation"
                    id="observation"
                    placeholder="Exemple : Remboursement journalier"
                >

            </div>

        </div>


        <button
            type="submit"
            class="btn btn-primary"
        >

            💵 Enregistrer le remboursement

        </button>

    </form>

</div>


<!-- CRÉDITS -->

<div class="card">

    <h2>
        💳 Crédits à rembourser
    </h2>


    <div class="table-container">

        <table>

            <thead>

                <tr>

                    <th>
                        Client
                    </th>

                    <th>
                        Crédit total
                    </th>

                    <th>
                        Déjà remboursé
                    </th>

                    <th>
                        Reste à rembourser
                    </th>

                    <th>
                        Statut
                    </th>

                </tr>

            </thead>


            <tbody>

            <?php if (empty($credits)): ?>

                <tr>

                    <td
                        colspan="5"
                        style="text-align:center;"
                    >

                        Aucun crédit en cours.

                    </td>

                </tr>

            <?php else: ?>


                <?php foreach ($credits as $credit): ?>

                    <?php

                    $reste =
                        (float)
                        $credit["solde_restant"];

                    ?>


                    <tr>

                        <td>

                            <strong>

                                <?= e(
                                    $credit["nom"]
                                    . " "
                                    . $credit["postnom"]
                                    . " "
                                    . $credit["prenom"]
                                ) ?>

                            </strong>

                            <br>

                            <small>

                                <?= e(
                                    $credit["telephone"]
                                ) ?>

                            </small>

                        </td>


                        <td>

                            <span class="amount">

                                <?= number_format(
                                    (float)
                                    $credit["montant_total"],
                                    2,
                                    ",",
                                    " "
                                ) ?>

                                $

                            </span>

                        </td>


                        <td>

                            <?= number_format(
                                (float)
                                $credit["montant_rembourse"],
                                2,
                                ",",
                                " "
                            ) ?>

                            $

                        </td>


                        <td>

                            <span
                                class="
                                remaining
                                <?= $reste <= 0
                                    ? 'zero'
                                    : ''
                                ?>
                                "
                            >

                                <?= number_format(
                                    $reste,
                                    2,
                                    ",",
                                    " "
                                ) ?>

                                $

                            </span>

                        </td>


                        <td>

                            <?php if (
                                $credit["statut"]
                                === "termine"
                            ): ?>

                                <span
                                    class="
                                    badge
                                    badge-termine
                                    "
                                >

                                    TERMINÉ

                                </span>

                            <?php else: ?>

                                <span
                                    class="
                                    badge
                                    badge-en-cours
                                    "
                                >

                                    EN COURS

                                </span>

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endforeach; ?>


            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>


<!-- HISTORIQUE -->

<div class="card">

    <h2>
        📋 Derniers remboursements
    </h2>


    <div class="table-container">

        <table>

            <thead>

                <tr>

                    <th>
                        Date
                    </th>

                    <th>
                        Client
                    </th>

                    <th>
                        Montant payé
                    </th>

                    <th>
                        Total remboursé
                    </th>

                    <th>
                        Reste
                    </th>

                    <th>
                        Statut
                    </th>

                    <th>
                        Observation
                    </th>

                </tr>

            </thead>


            <tbody>


            <?php if (empty($remboursements)): ?>

                <tr>

                    <td
                        colspan="7"
                        style="text-align:center;"
                    >

                        Aucun remboursement enregistré.

                    </td>

                </tr>

            <?php else: ?>


                <?php foreach (
                    $remboursements
                    as $remboursement
                ): ?>


                    <?php

                    $reste =
                        (float)
                        $remboursement[
                            "solde_restant"
                        ];

                    ?>


                    <tr>

                        <td>

                            <?= e(
                                $remboursement[
                                    "date_remboursement"
                                ]
                            ) ?>

                        </td>


                        <td>

                            <?= e(
                                $remboursement["nom"]
                                . " "
                                . $remboursement["postnom"]
                                . " "
                                . $remboursement["prenom"]
                            ) ?>

                        </td>


                        <td>

                            <strong>

                                <?= number_format(
                                    (float)
                                    $remboursement["montant"],
                                    2,
                                    ",",
                                    " "
                                ) ?>

                                $

                            </strong>

                        </td>


                        <td>

                            <?= number_format(
                                (float)
                                $remboursement[
                                    "montant_rembourse"
                                ],
                                2,
                                ",",
                                " "
                            ) ?>

                            $

                        </td>


                        <td>

                            <span
                                class="
                                remaining
                                <?= $reste <= 0
                                    ? 'zero'
                                    : ''
                                ?>
                                "
                            >

                                <?= number_format(
                                    $reste,
                                    2,
                                    ",",
                                    " "
                                ) ?>

                                $

                            </span>

                        </td>


                        <td>

                            <?php if (
                                $remboursement["statut"]
                                === "termine"
                            ): ?>

                                <span
                                    class="
                                    badge
                                    badge-termine
                                    "
                                >

                                    TERMINÉ

                                </span>

                            <?php else: ?>

                                <span
                                    class="
                                    badge
                                    badge-en-cours
                                    "
                                >

                                    EN COURS

                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?= e(
                                $remboursement[
                                    "observation"
                                ]
                            ) ?>

                        </td>

                    </tr>


                <?php endforeach; ?>


            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>


</main>

</div>


</body>

</html>