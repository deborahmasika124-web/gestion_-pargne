<?php

error_reporting(E_ALL);
ini_set("display_errors", "1");

require_once __DIR__ . "/config/database.php";

$database = new Database();
$db = $database->connect();

echo "<h2>TEST DES CLIENTS</h2>";

$stmt = $db->query("SELECT * FROM clients");

$clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<p>Nombre de clients trouvés : <strong>"
    . count($clients)
    . "</strong></p>";

echo "<pre>";
print_r($clients);
echo "</pre>";