<?php

$currentPage = basename($_SERVER["PHP_SELF"]);

?>

<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Gestion Épargne</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #333;
        }

        /* =========================
           BARRE SUPERIEURE
        ========================= */

        .topbar {
            height: 70px;

            background: linear-gradient(
                135deg,
                #0d6efd,
                #084298
            );

            color: white;

            display: flex;
            align-items: center;
            justify-content: space-between;

            padding: 0 30px;

            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.15);
        }

        .logo {
            font-size: 21px;
            font-weight: bold;
            letter-spacing: 0.5px;
        }

        .logo span {
            font-weight: normal;
            opacity: 0.85;
        }

        .user-info {
            font-size: 14px;

            background: rgba(255,255,255,0.15);

            padding: 9px 16px;

            border-radius: 25px;
        }

        /* =========================
           STRUCTURE
        ========================= */

        .layout {
            display: flex;
            min-height: calc(100vh - 70px);
        }

        /* =========================
           SIDEBAR
        ========================= */

        .sidebar {
            width: 240px;

            background: #212529;

            padding: 22px 12px;

            box-shadow:
                3px 0 10px rgba(0,0,0,0.08);
        }

        .menu-title {
            color: #8c98a4;

            font-size: 11px;

            text-transform: uppercase;

            letter-spacing: 1px;

            padding: 10px 15px;

            margin-bottom: 8px;
        }

        .sidebar a {
            display: block;

            color: #ddd;

            text-decoration: none;

            padding: 14px 15px;

            margin-bottom: 6px;

            border-radius: 8px;

            transition: all 0.25s ease;

            font-size: 15px;
        }

        .sidebar a:hover {
            background: #343a40;

            color: white;

            transform: translateX(3px);
        }

        .sidebar a.active {
            background: linear-gradient(
                135deg,
                #0d6efd,
                #0b5ed7
            );

            color: white;

            box-shadow:
                0 4px 12px rgba(13,110,253,0.30);
        }

        /* =========================
           DECONNEXION
        ========================= */

        .logout {
            margin-top: 30px;

            padding-top: 15px;

            border-top: 1px solid #343a40;
        }

        .logout a {
            color: #ffb3b3;
        }

        .logout a:hover {
            background: #3a2424;

            color: #ffdddd;
        }

        /* =========================
           CONTENU PRINCIPAL
        ========================= */

        .main {
            flex: 1;

            padding: 30px;

            min-width: 0;
        }

        /* =========================
           MESSAGE BIENVENUE
        ========================= */

        .welcome-box {

            background: linear-gradient(
                135deg,
                #0d6efd,
                #084298
            );

            color: white;

            padding: 30px;

            border-radius: 15px;

            margin-bottom: 25px;

            box-shadow:
                0 8px 25px rgba(13,110,253,0.20);
        }

        .welcome-box h1 {

            margin: 0 0 10px;

            font-size: 28px;
        }

        .welcome-box p {

            margin: 0;

            font-size: 15px;

            line-height: 1.6;

            opacity: 0.92;
        }

        .welcome-date {

            margin-top: 15px;

            font-size: 13px;

            opacity: 0.80;
        }

        /* =========================
           TITRE DE PAGE
        ========================= */

        .page-title {

            margin-top: 0;

            margin-bottom: 20px;

            font-size: 25px;
        }

        /* =========================
           CARTES
        ========================= */

        .card {

            background: white;

            border-radius: 12px;

            padding: 25px;

            box-shadow:
                0 3px 12px rgba(0,0,0,0.06);

            margin-bottom: 20px;
        }

        /* =========================
           BOUTONS
        ========================= */

        button,
        .btn {

            border: none;

            cursor: pointer;

            border-radius: 7px;

            padding: 10px 16px;

            font-size: 14px;
        }

        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 800px) {

            .sidebar {
                width: 210px;
            }

            .main {
                padding: 20px;
            }

        }

        @media (max-width: 600px) {

            .topbar {

                height: auto;

                min-height: 65px;

                padding: 12px 15px;

                gap: 10px;
            }

            .logo {

                font-size: 17px;
            }

            .logo span {

                display: none;
            }

            .user-info {

                font-size: 11px;

                padding: 7px 10px;
            }

            .layout {

                flex-direction: column;
            }

            .sidebar {

                width: 100%;

                padding: 10px;
            }

            .menu-title {

                display: none;
            }

            .sidebar a {

                display: inline-block;

                padding: 10px;

                margin: 2px;
            }

            .main {

                padding: 15px;
            }

            .welcome-box {

                padding: 22px;
            }

            .welcome-box h1 {

                font-size: 22px;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     BARRE SUPERIEURE
========================= -->

<div class="topbar">

    <div class="logo">

        GESTION ÉPARGNE

        <span>| Administration</span>

    </div>

    <div class="user-info">

        👤 Espace administrateur

    </div>

</div>


<!-- =========================
     STRUCTURE PRINCIPALE
========================= -->

<div class="layout">


    <!-- =========================
         MENU LATERAL
    ========================= -->

    <aside class="sidebar">

        <div class="menu-title">
            Navigation
        </div>


        <a
            href="dashboard.php"
            class="<?= $currentPage === 'dashboard.php' ? 'active' : '' ?>"
        >
            🏠 Tableau de bord
        </a>


        <a
            href="client.php"
            class="<?= $currentPage === 'client.php' ? 'active' : '' ?>"
        >
            👥 Clients
        </a>


        <a
            href="epargne.php"
            class="<?= $currentPage === 'epargne.php' ? 'active' : '' ?>"
        >
            💰 Épargne
        </a>


        <a
            href="credits.php"
            class="<?= $currentPage === 'credits.php' ? 'active' : '' ?>"
        >
            💳 Crédits
        </a>


        <a
            href="remboursement.php"
            class="<?= $currentPage === 'remboursement.php' ? 'active' : '' ?>"
        >
            💵 Remboursements
        </a>


        <div class="logout">

            <a href="logout.php">

                🚪 Déconnexion

            </a>

        </div>


    </aside>


    <!-- =========================
         CONTENU
    ========================= -->

    <main class="main">