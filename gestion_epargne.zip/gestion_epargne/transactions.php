<?php

require_once __DIR__ . "/config/bootstrap.php";

requireLogin();

/*
|--------------------------------------------------------------------------
| RÉCUPÉRATION DES TRANSACTIONS
|--------------------------------------------------------------------------
*/

$stmt = $db->query("
    SELECT
        t.id,
        t.type,
        t.montant,
        t.description,
        t.date_transaction,

        c.numero_compte,
        c.solde,

        cl.nom,
        cl.postnom,
        cl.prenom

    FROM transactions t

    INNER JOIN comptes_epargne c
        ON t.compte_id = c.id

    INNER JOIN clients cl
        ON c.client_id = cl.id

    ORDER BY t.date_transaction DESC, t.id DESC
");

$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| STATISTIQUES
|--------------------------------------------------------------------------
*/

$stmt = $db->query("
    SELECT
        COALESCE(SUM(
            CASE
                WHEN type = 'depot'
                THEN montant
                ELSE 0
            END
        ), 0) AS total_depots,

        COALESCE(SUM(
            CASE
                WHEN type = 'retrait'
                THEN montant
                ELSE 0
            END
        ), 0) AS total_retraits

    FROM transactions
");

$stats = $stmt->fetch(PDO::FETCH_ASSOC);

$totalDepots = (float) ($stats["total_depots"] ?? 0);
$totalRetraits = (float) ($stats["total_retraits"] ?? 0);


/*
|--------------------------------------------------------------------------
| AFFICHAGE
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/layout/header.php";

?>

<style>

.transactions-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 25px;

    gap: 20px;

}

.transactions-header h2 {

    margin: 0 0 7px;

    font-size: 25px;

}

.transactions-header p {

    margin: 0;

    color: #777;

}


/* ================================
   STATISTIQUES
================================ */

.transaction-stats {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 20px;

    margin-bottom: 25px;

}

.transaction-stat {

    background: white;

    padding: 22px;

    border-radius: 12px;

    box-shadow:
        0 3px 12px rgba(0,0,0,0.06);

}

.transaction-stat h3 {

    margin: 0 0 8px;

    font-size: 14px;

    color: #777;

}

.transaction-stat .amount {

    font-size: 25px;

    font-weight: bold;

}


/* ================================
   TABLE
================================ */

.transaction-card {

    background: white;

    border-radius: 12px;

    box-shadow:
        0 3px 12px rgba(0,0,0,0.06);

    overflow: hidden;

}

.table-container {

    width: 100%;

    overflow-x: auto;

}

table {

    width: 100%;

    border-collapse: collapse;

}

thead {

    background: #f1f4f8;

}

th {

    padding: 15px;

    text-align: left;

    font-size: 13px;

    color: #555;

    white-space: nowrap;

}

td {

    padding: 15px;

    border-top: 1px solid #eee;

    font-size: 14px;

    white-space: nowrap;

}

tbody tr:hover {

    background: #f8fafc;

}


/* ================================
   BADGES
================================ */

.badge {

    display: inline-block;

    padding: 6px 10px;

    border-radius: 20px;

    font-size: 12px;

    font-weight: bold;

}

.badge-depot {

    background: #d1e7dd;

    color: #0f5132;

}

.badge-retrait {

    background: #f8d7da;

    color: #842029;

}

.montant-depot {

    color: #198754;

    font-weight: bold;

}

.montant-retrait {

    color: #dc3545;

    font-weight: bold;

}

.no-data {

    text-align: center;

    padding: 45px;

    color: #777;

}


/* ================================
   RESPONSIVE
================================ */

@media (max-width: 900px) {

    .transaction-stats {

        grid-template-columns:
            1fr;

    }

}

@media (max-width: 600px) {

    .transactions-header {

        flex-direction: column;

        align-items: flex-start;

    }

}

</style>


<!-- ================================
     TITRE
================================ -->

<div class="transactions-header">

    <div>

        <h2>
            Historique des transactions
        </h2>

        <p>
            Consultez tous les dépôts et retraits effectués.
        </p>

    </div>

</div>


<!-- ================================
     STATISTIQUES
================================ -->

<div class="transaction-stats">

    <div class="transaction-stat">

        <h3>
            Nombre de transactions
        </h3>

        <div class="amount">

            <?= count($transactions) ?>

        </div>

    </div>


    <div class="transaction-stat">

        <h3>
            Total des dépôts
        </h3>

        <div
            class="amount montant-depot"
        >

            <?= number_format(
                $totalDepots,
                2,
                ",",
                " "
            ) ?>

            $

        </div>

    </div>


    <div class="transaction-stat">

        <h3>
            Total des retraits
        </h3>

        <div
            class="amount montant-retrait"
        >

            <?= number_format(
                $totalRetraits,
                2,
                ",",
                " "
            ) ?>

            $

        </div>

    </div>

</div>


<!-- ================================
     TABLEAU
================================ -->

<div class="transaction-card">

    <div class="table-container">

        <table>

            <thead>

                <tr>

                    <th>
                        #
                    </th>

                    <th>
                        Date
                    </th>

                    <th>
                        Client
                    </th>

                    <th>
                        Compte
                    </th>

                    <th>
                        Type
                    </th>

                    <th>
                        Montant
                    </th>

                    <th>
                        Description
                    </th>

                    <th>
                        Solde actuel
                    </th>

                </tr>

            </thead>


            <tbody>

            <?php if (empty($transactions)): ?>

                <tr>

                    <td
                        colspan="8"
                        class="no-data"
                    >

                        Aucune transaction
                        enregistrée pour le moment.

                    </td>

                </tr>

            <?php else: ?>

                <?php foreach (
                    $transactions
                    as $transaction
                ): ?>

                    <tr>

                        <td>

                            <?= e(
                                $transaction["id"]
                            ) ?>

                        </td>


                        <td>

                            <?= e(
                                date(
                                    "d/m/Y H:i",
                                    strtotime(
                                        $transaction[
                                            "date_transaction"
                                        ]
                                    )
                                )
                            ) ?>

                        </td>


                        <td>

                            <strong>

                                <?= e(
                                    trim(
                                        $transaction["nom"]
                                        . " "
                                        . $transaction["postnom"]
                                        . " "
                                        . $transaction["prenom"]
                                    )
                                ) ?>

                            </strong>

                        </td>


                        <td>

                            <?= e(
                                $transaction[
                                    "numero_compte"
                                ]
                            ) ?>

                        </td>


                        <td>

                            <?php if (
                                strtolower(
                                    $transaction["type"]
                                ) === "depot"
                            ): ?>

                                <span
                                    class="badge badge-depot"
                                >
                                    ↑ Dépôt
                                </span>

                            <?php else: ?>

                                <span
                                    class="badge badge-retrait"
                                >
                                    ↓ Retrait
                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?php if (
                                strtolower(
                                    $transaction["type"]
                                ) === "depot"
                            ): ?>

                                <span
                                    class="montant-depot"
                                >

                                    +

                                    <?= number_format(
                                        (float)
                                        $transaction[
                                            "montant"
                                        ],
                                        2,
                                        ",",
                                        " "
                                    ) ?>

                                    $

                                </span>

                            <?php else: ?>

                                <span
                                    class="montant-retrait"
                                >

                                    -

                                    <?= number_format(
                                        (float)
                                        $transaction[
                                            "montant"
                                        ],
                                        2,
                                        ",",
                                        " "
                                    ) ?>

                                    $

                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?= e(
                                $transaction[
                                    "description"
                                ] ?: "-"
                            ) ?>

                        </td>


                        <td>

                            <strong>

                                <?= number_format(
                                    (float)
                                    $transaction["solde"],
                                    2,
                                    ",",
                                    " "
                                ) ?>

                                $

                            </strong>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>


<?php

require_once __DIR__ . "/layout/footer.php";

?>