<?php

session_start();

require_once __DIR__ . "/config/database.php";


/*
|--------------------------------------------------------------------------
| Si déjà connecté
|--------------------------------------------------------------------------
*/

if (isset($_SESSION["user_id"])) {

    header("Location: dashboard.php");

    exit;
}


/*
|--------------------------------------------------------------------------
| Connexion
|--------------------------------------------------------------------------
*/

$erreur = "";


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");

    $motDePasse = $_POST["mot_de_passe"] ?? "";


    if ($email === "" || $motDePasse === "") {

        $erreur = "Veuillez remplir tous les champs.";

    } else {

        try {

            $database = new Database();

            $db = $database->connect();


            $stmt = $db->prepare("
                SELECT
                    id,
                    nom,
                    email,
                    mot_de_passe,
                    role
                FROM users
                WHERE email = ?
                LIMIT 1
            ");


            $stmt->execute([
                $email
            ]);


            $user = $stmt->fetch(PDO::FETCH_ASSOC);


            if (
                $user &&
                password_verify(
                    $motDePasse,
                    $user["mot_de_passe"]
                )
            ) {

                /*
                |----------------------------------------------------------
                | Création de la session
                |----------------------------------------------------------
                */

                $_SESSION["user_id"] = $user["id"];

                $_SESSION["user_nom"] = $user["nom"];

                $_SESSION["user_email"] = $user["email"];

                $_SESSION["user_role"] = $user["role"];


                /*
                |----------------------------------------------------------
                | Redirection vers le tableau de bord
                |----------------------------------------------------------
                */

                header("Location: dashboard.php");

                exit;

            } else {

                $erreur = "Email ou mot de passe incorrect.";

            }

        } catch (PDOException $e) {

            $erreur = "Erreur de connexion à la base de données.";

        }

    }

}

?>

<!DOCTYPE html>

<html lang="fr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Connexion - Gestion Épargne
    </title>


    <style>

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            min-height: 100vh;

            font-family:
                Arial,
                Helvetica,
                sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #0d6efd,
                    #084298
                );

            display: flex;

            align-items: center;

            justify-content: center;

            padding: 20px;
        }


        .login-container {

            width: 100%;

            max-width: 430px;
        }


        .brand {

            text-align: center;

            color: white;

            margin-bottom: 25px;
        }


        .brand-icon {

            font-size: 45px;

            margin-bottom: 8px;
        }


        .brand h1 {

            margin: 0;

            font-size: 27px;
        }


        .brand p {

            margin-top: 8px;

            opacity: 0.85;

            font-size: 14px;
        }


        .login-box {

            background: white;

            border-radius: 16px;

            padding: 35px;

            box-shadow:
                0 15px 40px
                rgba(0, 0, 0, 0.20);
        }


        .login-box h2 {

            text-align: center;

            margin-top: 0;

            margin-bottom: 8px;

            color: #222;
        }


        .login-subtitle {

            text-align: center;

            color: #777;

            font-size: 14px;

            margin-bottom: 25px;
        }


        .form-group {

            margin-bottom: 18px;
        }


        .form-group label {

            display: block;

            margin-bottom: 7px;

            font-size: 14px;

            font-weight: bold;

            color: #444;
        }


        .form-group input {

            width: 100%;

            padding: 13px 14px;

            border: 1px solid #ddd;

            border-radius: 8px;

            font-size: 15px;

            outline: none;

            transition: 0.2s;
        }


        .form-group input:focus {

            border-color: #0d6efd;

            box-shadow:
                0 0 0 3px
                rgba(13,110,253,0.10);
        }


        .error {

            background: #f8d7da;

            color: #842029;

            border: 1px solid #f5c2c7;

            padding: 12px;

            border-radius: 8px;

            margin-bottom: 18px;

            font-size: 14px;
        }


        .login-button {

            width: 100%;

            border: none;

            background:
                linear-gradient(
                    135deg,
                    #0d6efd,
                    #084298
                );

            color: white;

            padding: 14px;

            border-radius: 8px;

            font-size: 15px;

            font-weight: bold;

            cursor: pointer;

            transition: 0.2s;
        }


        .login-button:hover {

            transform: translateY(-1px);

            box-shadow:
                0 5px 12px
                rgba(13,110,253,0.25);
        }


        .footer-text {

            text-align: center;

            color: #888;

            font-size: 12px;

            margin-top: 22px;
        }


        @media (max-width: 500px) {

            .login-box {

                padding: 25px 20px;
            }

        }

    </style>

</head>


<body>


<div class="login-container">


    <!-- LOGO -->

    <div class="brand">

        <div class="brand-icon">
            💰
        </div>

        <h1>
            GESTION ÉPARGNE
        </h1>

        <p>
            Plateforme de gestion des épargnes et crédits
        </p>

    </div>


    <!-- CONNEXION -->

    <div class="login-box">

        <h2>
            👋 Bienvenue
        </h2>

        <div class="login-subtitle">
            Connectez-vous à votre espace de gestion
        </div>


        <?php if ($erreur !== ""): ?>

            <div class="error">

                <?= htmlspecialchars(
                    $erreur,
                    ENT_QUOTES,
                    "UTF-8"
                ) ?>

            </div>

        <?php endif; ?>


        <form
            method="POST"
            action="login.php"
        >


            <div class="form-group">

                <label for="email">
                    Adresse email
                </label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="admin@gestion.com"
                    value="<?= htmlspecialchars(
                        $_POST["email"] ?? "",
                        ENT_QUOTES,
                        "UTF-8"
                    ) ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label for="mot_de_passe">
                    Mot de passe
                </label>

                <input
                    type="password"
                    id="mot_de_passe"
                    name="mot_de_passe"
                    placeholder="Votre mot de passe"
                    required
                >

            </div>


            <button
                type="submit"
                class="login-button"
            >

                🔐 Se connecter

            </button>


        </form>


        <div class="footer-text">

            Gestion Épargne © <?= date("Y") ?>

        </div>

    </div>

</div>


</body>

</html>