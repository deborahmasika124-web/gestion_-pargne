<?php

require_once __DIR__ . "/config/bootstrap.php";

requireLogin();

$message = "";
$typeMessage = "";

/*
|--------------------------------------------------------------------------
| TRAITEMENT DES ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";

    /*
    |--------------------------------------------------------------------------
    | AJOUT D'UN CREDIT
    |--------------------------------------------------------------------------
    */
    if ($action === "ajouter") {

        $clientId = (int) ($_POST["client_id"] ?? 0);
        $montant = (float) ($_POST["montant"] ?? 0);
        $taux = (float) ($_POST["taux"] ?? 0);
        $duree = (int) ($_POST["duree"] ?? 0);

        if ($clientId <= 0) {
            $message = "Veuillez sélectionner un client.";
            $typeMessage = "danger";
        } elseif ($montant <= 0) {
            $message = "Le montant du crédit doit être supérieur à 0.";
            $typeMessage = "danger";
        } elseif ($duree <= 0) {
            $message = "La durée doit être supérieure à 0 jour.";
            $typeMessage = "danger";
        } elseif ($taux < 0) {
            $message = "Le taux ne peut pas être négatif.";
            $typeMessage = "danger";
        } else {

            /*
             * Calcul des montants
             *
             * Exemple :
             * Crédit = 100 000
             * Taux = 10%
             * Intérêt = 10 000
             * Total = 110 000
             */
            $interet = $montant * ($taux / 100);

            $montantTotal = $montant + $interet;

            $montantJournalier = $montantTotal / $duree;

            $montantRembourse = 0;

            $soldeRestant = $montantTotal;

            $dateDemande = date("Y-m-d");

            try {

                $sql = "
                    INSERT INTO credits
                    (
                        client_id,
                        montant,
                        taux,
                        duree,
                        montant_total,
                        montant_journalier,
                        montant_rembourse,
                        solde_restant,
                        date_demande,
                        statut
                    )
                    VALUES
                    (
                        :client_id,
                        :montant,
                        :taux,
                        :duree,
                        :montant_total,
                        :montant_journalier,
                        :montant_rembourse,
                        :solde_restant,
                        :date_demande,
                        'en_attente'
                    )
                ";

                $stmt = $db->prepare($sql);

                $stmt->execute([
                    ":client_id" => $clientId,
                    ":montant" => $montant,
                    ":taux" => $taux,
                    ":duree" => $duree,
                    ":montant_total" => $montantTotal,
                    ":montant_journalier" => $montantJournalier,
                    ":montant_rembourse" => $montantRembourse,
                    ":solde_restant" => $soldeRestant,
                    ":date_demande" => $dateDemande
                ]);

                $message = "Le crédit a été enregistré avec succès.";
                $typeMessage = "success";

            } catch (PDOException $e) {

                $message = "Erreur lors de l'enregistrement : " . $e->getMessage();
                $typeMessage = "danger";
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | APPROUVER UN CREDIT
    |--------------------------------------------------------------------------
    */
    if ($action === "approuver") {

        $creditId = (int) ($_POST["credit_id"] ?? 0);

        if ($creditId > 0) {

            try {

                $sql = "
                    UPDATE credits
                    SET
                        statut = 'en_cours',
                        date_decaissement = :date_decaissement
                    WHERE id = :id
                    AND statut = 'en_attente'
                ";

                $stmt = $db->prepare($sql);

                $stmt->execute([
                    ":date_decaissement" => date("Y-m-d"),
                    ":id" => $creditId
                ]);

                if ($stmt->rowCount() > 0) {

                    $message = "Le crédit a été approuvé et mis en cours.";
                    $typeMessage = "success";

                } else {

                    $message = "Ce crédit ne peut pas être approuvé.";
                    $typeMessage = "warning";
                }

            } catch (PDOException $e) {

                $message = "Erreur : " . $e->getMessage();
                $typeMessage = "danger";
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REJETER UN CREDIT
    |--------------------------------------------------------------------------
    */
    if ($action === "rejeter") {

        $creditId = (int) ($_POST["credit_id"] ?? 0);

        if ($creditId > 0) {

            try {

                $sql = "
                    UPDATE credits
                    SET statut = 'rejete'
                    WHERE id = :id
                    AND statut = 'en_attente'
                ";

                $stmt = $db->prepare($sql);

                $stmt->execute([
                    ":id" => $creditId
                ]);

                if ($stmt->rowCount() > 0) {

                    $message = "Le crédit a été rejeté.";
                    $typeMessage = "success";

                } else {

                    $message = "Ce crédit ne peut pas être rejeté.";
                    $typeMessage = "warning";
                }

            } catch (PDOException $e) {

                $message = "Erreur : " . $e->getMessage();
                $typeMessage = "danger";
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| RECUPERATION DES CLIENTS
|--------------------------------------------------------------------------
*/

$stmtClients = $db->query("
    SELECT
        id,
        nom,
        telephone
    FROM clients
    ORDER BY nom ASC
");

$clients = $stmtClients->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| RECUPERATION DES CREDITS
|--------------------------------------------------------------------------
*/

$stmtCredits = $db->query("
    SELECT
        credits.*,
        clients.nom,
        clients.telephone
    FROM credits
    INNER JOIN clients
        ON clients.id = credits.client_id
    ORDER BY credits.id DESC
");

$credits = $stmtCredits->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| STATISTIQUES
|--------------------------------------------------------------------------
*/

$stmtStats = $db->query("
    SELECT

        COUNT(*) AS nombre_credits,

        COALESCE(SUM(montant), 0) AS montant_accorde,

        COALESCE(SUM(montant_total), 0) AS montant_total,

        COALESCE(SUM(montant_rembourse), 0) AS montant_rembourse,

        COALESCE(SUM(solde_restant), 0) AS solde_restant

    FROM credits
");

$stats = $stmtStats->fetch(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| FORMATAGE
|--------------------------------------------------------------------------
*/

function formatMontant($montant): string
{
    return number_format(
        (float) $montant,
        2,
        ",",
        " "
    );
}

function statutLabel($statut): string
{
    switch ($statut) {

        case "en_attente":
            return "En attente";

        case "approuve":
            return "Approuvé";

        case "en_cours":
            return "En cours";

        case "rejete":
            return "Rejeté";

        case "termine":
            return "Terminé";

        default:
            return ucfirst(str_replace("_", " ", $statut));
    }
}

function statutClass($statut): string
{
    switch ($statut) {

        case "en_attente":
            return "warning";

        case "approuve":
            return "info";

        case "en_cours":
            return "primary";

        case "rejete":
            return "danger";

        case "termine":
            return "success";

        default:
            return "secondary";
    }
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Gestion des crédits</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #333;
        }

        .container {
            width: 95%;
            max-width: 1400px;
            margin: 30px auto;
        }

        .header {
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .header h1 {
            margin: 0 0 8px 0;
        }

        .header p {
            margin: 0;
            color: #777;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d1e7dd;
            color: #0f5132;
        }

        .alert-danger {
            background: #f8d7da;
            color: #842029;
        }

        .alert-warning {
            background: #fff3cd;
            color: #664d03;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .stat-card h3 {
            margin: 0 0 10px;
            font-size: 14px;
            color: #777;
        }

        .stat-card strong {
            font-size: 24px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .card h2 {
            margin-top: 0;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 7px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            padding: 11px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        .btn {
            border: none;
            padding: 11px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        .btn-primary {
            background: #0d6efd;
            color: white;
        }

        .btn-success {
            background: #198754;
            color: white;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1100px;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #f1f3f5;
        }

        .badge {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge-warning {
            background: #fff3cd;
            color: #664d03;
        }

        .badge-primary {
            background: #cfe2ff;
            color: #084298;
        }

        .badge-info {
            background: #cff4fc;
            color: #055160;
        }

        .badge-danger {
            background: #f8d7da;
            color: #842029;
        }

        .badge-success {
            background: #d1e7dd;
            color: #0f5132;
        }

        .badge-secondary {
            background: #e2e3e5;
            color: #41464b;
        }

        .actions {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .actions form {
            margin: 0;
        }

        .calculation {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }

        .calculation strong {
            font-size: 18px;
        }

        @media (max-width: 1000px) {

            .stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .form-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {

            .stats {
                grid-template-columns: 1fr;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }
        }

    </style>

</head>

<body>

<div class="container">

    <div class="header">

        <h1>Gestion des crédits</h1>

        <p>
            Demandes de crédits, calcul des remboursements et suivi des soldes.
        </p>

    </div>


    <?php if ($message !== ""): ?>

        <div class="alert alert-<?= e($typeMessage) ?>">

            <?= e($message) ?>

        </div>

    <?php endif; ?>


    <!-- STATISTIQUES -->

    <div class="stats">

        <div class="stat-card">

            <h3>Nombre de crédits</h3>

            <strong>
                <?= (int) ($stats["nombre_credits"] ?? 0) ?>
            </strong>

        </div>


        <div class="stat-card">

            <h3>Montant accordé</h3>

            <strong>
                <?= formatMontant($stats["montant_accorde"] ?? 0) ?>
            </strong>

        </div>


        <div class="stat-card">

            <h3>Total à rembourser</h3>

            <strong>
                <?= formatMontant($stats["montant_total"] ?? 0) ?>
            </strong>

        </div>


        <div class="stat-card">

            <h3>Solde restant</h3>

            <strong>
                <?= formatMontant($stats["solde_restant"] ?? 0) ?>
            </strong>

        </div>

    </div>


    <!-- FORMULAIRE -->

    <div class="card">

        <h2>Nouvelle demande de crédit</h2>

        <form method="POST">

            <input
                type="hidden"
                name="action"
                value="ajouter"
            >

            <div class="form-grid">

                <div class="form-group">

                    <label for="client_id">
                        Client
                    </label>

                    <select
                        name="client_id"
                        id="client_id"
                        required
                    >

                        <option value="">
                            -- Sélectionner un client --
                        </option>

                        <?php foreach ($clients as $client): ?>

                            <option
                                value="<?= (int) $client["id"] ?>"
                            >

                                <?= e($client["nom"]) ?>

                                -
                                <?= e($client["telephone"]) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="form-group">

                    <label for="montant">
                        Montant du crédit
                    </label>

                    <input
                        type="number"
                        name="montant"
                        id="montant"
                        min="1"
                        step="0.01"
                        placeholder="Ex : 100000"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="taux">
                        Taux (%)
                    </label>

                    <input
                        type="number"
                        name="taux"
                        id="taux"
                        min="0"
                        step="0.01"
                        value="0"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="duree">
                        Durée (jours)
                    </label>

                    <input
                        type="number"
                        name="duree"
                        id="duree"
                        min="1"
                        placeholder="Ex : 30"
                        required
                    >

                </div>

            </div>


            <div class="calculation">

                <p>
                    <strong>Montant total :</strong>
                    <span id="montantTotal">
                        0,00
                    </span>
                </p>

                <p>
                    <strong>Remboursement journalier :</strong>
                    <span id="montantJournalier">
                        0,00
                    </span>
                </p>

            </div>


            <br>

            <button
                type="submit"
                class="btn btn-primary"
            >
                Enregistrer le crédit
            </button>

        </form>

    </div>


    <!-- LISTE DES CREDITS -->

    <div class="card">

        <h2>Liste des crédits</h2>

        <div class="table-container">

            <table>

                <thead>

                <tr>

                    <th>ID</th>

                    <th>Client</th>

                    <th>Montant</th>

                    <th>Taux</th>

                    <th>Durée</th>

                    <th>Total</th>

                    <th>Journalier</th>

                    <th>Remboursé</th>

                    <th>Solde</th>

                    <th>Date demande</th>

                    <th>Statut</th>

                    <th>Actions</th>

                </tr>

                </thead>


                <tbody>

                <?php if (count($credits) === 0): ?>

                    <tr>

                        <td
                            colspan="12"
                            style="text-align:center;"
                        >

                            Aucun crédit enregistré.

                        </td>

                    </tr>

                <?php else: ?>

                    <?php foreach ($credits as $credit): ?>

                        <tr>

                            <td>
                                <?= (int) $credit["id"] ?>
                            </td>


                            <td>

                                <strong>
                                    <?= e($credit["nom"]) ?>
                                </strong>

                                <br>

                                <small>
                                    <?= e($credit["telephone"]) ?>
                                </small>

                            </td>


                            <td>
                                <?= formatMontant($credit["montant"]) ?>
                            </td>


                            <td>
                                <?= number_format(
                                    (float) $credit["taux"],
                                    2,
                                    ",",
                                    " "
                                ) ?> %
                            </td>


                            <td>
                                <?= (int) $credit["duree"] ?> jours
                            </td>


                            <td>
                                <?= formatMontant($credit["montant_total"]) ?>
                            </td>


                            <td>
                                <?= formatMontant($credit["montant_journalier"]) ?>
                            </td>


                            <td>
                                <?= formatMontant($credit["montant_rembourse"]) ?>
                            </td>


                            <td>
                                <strong>
                                    <?= formatMontant($credit["solde_restant"]) ?>
                                </strong>
                            </td>


                            <td>
                                <?= e($credit["date_demande"]) ?>
                            </td>


                            <td>

                                <span
                                    class="badge badge-<?= e(
                                        statutClass($credit["statut"])
                                    ) ?>"
                                >

                                    <?= e(
                                        statutLabel($credit["statut"])
                                    ) ?>

                                </span>

                            </td>


                            <td>

                                <div class="actions">

                                    <?php if ($credit["statut"] === "en_attente"): ?>

                                        <form
                                            method="POST"
                                            onsubmit="return confirm('Voulez-vous approuver ce crédit ?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="action"
                                                value="approuver"
                                            >

                                            <input
                                                type="hidden"
                                                name="credit_id"
                                                value="<?= (int) $credit["id"] ?>"
                                            >

                                            <button
                                                type="submit"
                                                class="btn btn-success"
                                            >
                                                Approuver
                                            </button>

                                        </form>


                                        <form
                                            method="POST"
                                            onsubmit="return confirm('Voulez-vous rejeter ce crédit ?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="action"
                                                value="rejeter"
                                            >

                                            <input
                                                type="hidden"
                                                name="credit_id"
                                                value="<?= (int) $credit["id"] ?>"
                                            >

                                            <button
                                                type="submit"
                                                class="btn btn-danger"
                                            >
                                                Rejeter
                                            </button>

                                        </form>

                                    <?php elseif ($credit["statut"] === "en_cours"): ?>

                                        <span class="badge badge-primary">
                                            Remboursement en cours
                                        </span>

                                    <?php elseif ($credit["statut"] === "rejete"): ?>

                                        <span class="badge badge-danger">
                                            Crédit rejeté
                                        </span>

                                    <?php endif; ?>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<script>

    const montantInput =
        document.getElementById("montant");

    const tauxInput =
        document.getElementById("taux");

    const dureeInput =
        document.getElementById("duree");

    const montantTotal =
        document.getElementById("montantTotal");

    const montantJournalier =
        document.getElementById("montantJournalier");


    function calculerCredit() {

        const montant =
            parseFloat(montantInput.value) || 0;

        const taux =
            parseFloat(tauxInput.value) || 0;

        const duree =
            parseInt(dureeInput.value) || 0;


        const interet =
            montant * (taux / 100);

        const total =
            montant + interet;


        let journalier = 0;

        if (duree > 0) {
            journalier = total / duree;
        }


        montantTotal.textContent =
            total.toLocaleString(
                "fr-FR",
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );


        montantJournalier.textContent =
            journalier.toLocaleString(
                "fr-FR",
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );
    }


    montantInput.addEventListener(
        "input",
        calculerCredit
    );

    tauxInput.addEventListener(
        "input",
        calculerCredit
    );

    dureeInput.addEventListener(
        "input",
        calculerCredit
    );

</script>

</body>

</html>