<?php

require_once __DIR__ . "/config/database.php";

$database = new Database();
$db = $database->connect();

$nouveauMotDePasse = "Admin@2026!";

$hash = password_hash(
    $nouveauMotDePasse,
    PASSWORD_DEFAULT
);

$stmt = $db->prepare("
    UPDATE users
    SET mot_de_passe = ?
    WHERE email = ?
");

$stmt->execute([
    $hash,
    "admin@gestion.com"
]);

if ($stmt->rowCount() > 0) {

    echo "<h2>Mot de passe réinitialisé avec succès.</h2>";

    echo "<p>Email : <strong>admin@gestion.com</strong></p>";

    echo "<p>Mot de passe : <strong>Admin@2026!</strong></p>";

    echo "<p>Tu peux maintenant te connecter.</p>";

} else {

    echo "Aucune modification effectuée.";

}