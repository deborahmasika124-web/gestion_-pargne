document.addEventListener("DOMContentLoaded", function () {

    const menuButton =
        document.getElementById("menuButton");

    const sidebar =
        document.getElementById("sidebar");


    if (menuButton && sidebar) {

        menuButton.addEventListener(
            "click",
            function () {

                sidebar.classList.toggle("open");

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | CONFIRMATION DES SUPPRESSIONS
    |--------------------------------------------------------------------------
    */

    const deleteButtons =
        document.querySelectorAll(
            "[data-confirm-delete]"
        );

    deleteButtons.forEach(function (button) {

        button.addEventListener(
            "click",
            function (event) {

                const message =
                    button.dataset.confirmDelete
                    ||
                    "Voulez-vous vraiment supprimer cet élément ?";

                if (!confirm(message)) {

                    event.preventDefault();

                }

            }
        );

    });


    /*
    |--------------------------------------------------------------------------
    | FERMETURE AUTOMATIQUE DES ALERTES
    |--------------------------------------------------------------------------
    */

    const alerts =
        document.querySelectorAll(".alert");

    alerts.forEach(function (alert) {

        setTimeout(function () {

            alert.style.opacity = "0";

            setTimeout(function () {

                alert.remove();

            }, 500);

        }, 5000);

    });

});