<?php

error_reporting(E_ALL);
ini_set("display_errors", "1");

require_once __DIR__ . "/config/database.php";

$database = new Database();
$db = $database->connect();

$nom = "Administrateur";
$email = "admin@gestion.com";
$motDePasse = "password";
$role = "admin";

$hash = password_hash(
    $motDePasse,
    PASSWORD_DEFAULT
);

/*
 * Vérifier si l'administrateur existe déjà
 */
$stmt = $db->prepare("
    SELECT id
    FROM users
    WHERE email = ?
    LIMIT 1
");

$stmt->execute([$email]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {

    /*
     * L'utilisateur existe :
     * on corrige son mot de passe et son rôle
     */

    $stmt = $db->prepare("
        UPDATE users
        SET
            nom = ?,
            mot_de_passe = ?,
            role = ?
        WHERE email = ?
    ");

    $stmt->execute([
        $nom,
        $hash,
        $role,
        $email
    ]);

    echo "<h2>Administrateur mis à jour avec succès.</h2>";

} else {

    /*
     * L'utilisateur n'existe pas :
     * on le crée
     */

    $stmt = $db->prepare("
        INSERT INTO users
        (
            nom,
            email,
            mot_de_passe,
            role
        )
        VALUES (?, ?, ?, ?)
    ");

    $stmt->execute([
        $nom,
        $email,
        $hash,
        $role
    ]);

    echo "<h2>Administrateur créé avec succès.</h2>";
}

echo "<hr>";

echo "<p><strong>Nom :</strong> Administrateur</p>";
echo "<p><strong>Email :</strong> admin@gestion.com</p>";
echo "<p><strong>Mot de passe :</strong> password</p>";
echo "<p><strong>Rôle :</strong> admin</p>";

echo "<hr>";

echo "<p style='color:red;'>
Après cette opération, supprime le fichier
<strong>setup_admin.php</strong>.
</p>";