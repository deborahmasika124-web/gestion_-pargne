<?php

error_reporting(E_ALL);
ini_set("display_errors", "1");

require_once __DIR__ . "/config/database.php";

$database = new Database();
$db = $database->connect();

$nom = "Administrateur";
$email = "admin@gestion.com";
$motDePasse = "password";
$role = "admin";

$motDePasseHash = password_hash(
    $motDePasse,
    PASSWORD_DEFAULT
);

$sql = "
    INSERT INTO users
    (nom, email, mot_de_passe, role)
    VALUES (?, ?, ?, ?)
";

$stmt = $db->prepare($sql);

$stmt->execute([
    $nom,
    $email,
    $motDePasseHash,
    $role
]);

echo "<h2>Administrateur créé avec succès.</h2>";
echo "<p>Email : <strong>admin@gestion.com</strong></p>";
echo "<p>Mot de passe : <strong>password</strong></p>";
echo "<p>Tu peux maintenant supprimer le fichier create_admin.php.</p>";