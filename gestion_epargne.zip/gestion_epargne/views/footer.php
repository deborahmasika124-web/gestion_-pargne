        </main>

        <footer class="footer">

            <span>
                © <?= date("Y") ?> Gestion Épargne
            </span>

            <span>
                Plateforme de gestion financière
            </span>

        </footer>

    </div>

</div>

<script src="assets/js/app.js"></script>

</body>

</html>