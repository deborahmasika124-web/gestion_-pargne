<?php

$currentPage = basename($_SERVER["PHP_SELF"]);

?>

<aside class="sidebar" id="sidebar">

    <div class="logo">

        <div class="logo-icon">
            GE
        </div>

        <div>

            <strong>
                Gestion
            </strong>

            <span>
                Épargne
            </span>

        </div>

    </div>


    <div class="menu-title">
        MENU PRINCIPAL
    </div>


    <nav class="navigation">

        <a
            href="dashboard.php"
            class="<?= $currentPage === 'dashboard.php'
                ? 'active'
                : '' ?>"
        >

            <span class="nav-icon">▦</span>

            <span>
                Tableau de bord
            </span>

        </a>


        <a
            href="clients.php"
            class="<?= $currentPage === 'clients.php'
                ? 'active'
                : '' ?>"
        >

            <span class="nav-icon">👥</span>

            <span>
                Clients
            </span>

        </a>


        <a
            href="epargne.php"
            class="<?= $currentPage === 'epargne.php'
                ? 'active'
                : '' ?>"
        >

            <span class="nav-icon">💰</span>

            <span>
                Épargne
            </span>

        </a>


        <a
            href="credits.php"
            class="<?= $currentPage === 'credits.php'
                ? 'active'
                : '' ?>"
        >

            <span class="nav-icon">💳</span>

            <span>
                Crédits
            </span>

        </a>


        <a
            href="remboursements.php"
            class="<?= $currentPage === 'remboursements.php'
                ? 'active'
                : '' ?>"
        >

            <span class="nav-icon">↻</span>

            <span>
                Remboursements
            </span>

        </a>

    </nav>


    <div class="menu-title">
        COMPTE
    </div>


    <nav class="navigation">

        <a href="logout.php">

            <span class="nav-icon">
                ⎋
            </span>

            <span>
                Déconnexion
            </span>

        </a>

    </nav>


    <div class="sidebar-footer">

        <div class="secure-icon">
            🔒
        </div>

        <div>

            <strong>
                Système sécurisé
            </strong>

            <small>
                Gestion financière
            </small>

        </div>

    </div>

</aside>