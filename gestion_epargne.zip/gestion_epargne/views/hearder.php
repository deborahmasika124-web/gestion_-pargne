<?php

if (empty($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

$currentPage = basename($_SERVER["PHP_SELF"]);

?>

<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?= isset($pageTitle)
            ? htmlspecialchars($pageTitle)
            : "Gestion Épargne"
        ?>
    </title>

    <link
        rel="stylesheet"
        href="assets/css/style.css"
    >

</head>

<body>

<div class="app">

    <?php include __DIR__ . "/sidebar.php"; ?>

    <div class="main-area">

        <header class="topbar">

            <button
                type="button"
                class="menu-button"
                id="menuButton"
            >
                ☰
            </button>

            <div class="topbar-title">

                <h2>
                    <?= isset($pageTitle)
                        ? htmlspecialchars($pageTitle)
                        : "Tableau de bord"
                    ?>
                </h2>

            </div>

            <div class="user-menu">

                <div class="user-avatar">
                    <?= strtoupper(
                        substr(
                            $_SESSION["user"]["nom"],
                            0,
                            1
                        )
                    ) ?>
                </div>

                <div class="user-info">

                    <strong>
                        <?= htmlspecialchars(
                            $_SESSION["user"]["nom"]
                        ) ?>
                    </strong>

                    <small>
                        <?= htmlspecialchars(
                            $_SESSION["user"]["role"]
                        ) ?>
                    </small>

                </div>

                <a
                    href="logout.php"
                    class="logout-link"
                    title="Déconnexion"
                >
                    ⎋
                </a>

            </div>

        </header>

        <main class="content">