<?php

require_once __DIR__ . "/config/bootstrap.php";

requireLogin();

/*
|--------------------------------------------------------------------------
| STATISTIQUES
|--------------------------------------------------------------------------
*/

$stmt = $db->query("
    SELECT COUNT(*)
    FROM clients
");

$totalClients = $stmt->fetchColumn();


$stmt = $db->query("
    SELECT COUNT(*)
    FROM comptes_epargne
");

$totalComptes = $stmt->fetchColumn();


$stmt = $db->query("
    SELECT COALESCE(SUM(solde), 0)
    FROM comptes_epargne
    WHERE statut = 'actif'
");

$totalEpargne = $stmt->fetchColumn();


$stmt = $db->query("
    SELECT COUNT(*)
    FROM credits
");

$totalCredits = $stmt->fetchColumn();


$stmt = $db->query("
    SELECT COALESCE(SUM(montant), 0)
    FROM credits
    WHERE statut IN ('approuve', 'en_cours', 'termine')
");

$totalCreditsAccordes = $stmt->fetchColumn();


$stmt = $db->query("
    SELECT COALESCE(SUM(montant), 0)
    FROM remboursements
");

$totalRembourse = $stmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| DATE
|--------------------------------------------------------------------------
*/

$dateActuelle = date("d/m/Y");


/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/layout/header.php";

?>

<style>

.dashboard-title {
    margin-bottom: 25px;
}

.dashboard-title h2 {
    margin: 0 0 8px;
    font-size: 24px;
}

.dashboard-title p {
    margin: 0;
    color: #777;
}


/* =========================
   STATISTIQUES
========================= */

.dashboard-stats {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 20px;
}


.dashboard-card {

    background: white;

    padding: 25px;

    border-radius: 14px;

    box-shadow:
        0 3px 12px rgba(0,0,0,0.07);

    transition:
        transform 0.25s ease,
        box-shadow 0.25s ease;
}


.dashboard-card:hover {

    transform: translateY(-4px);

    box-shadow:
        0 8px 20px rgba(0,0,0,0.12);
}


.dashboard-icon {

    font-size: 30px;

    margin-bottom: 15px;
}


.dashboard-card h3 {

    margin: 0 0 10px;

    color: #666;

    font-size: 15px;

    font-weight: normal;
}


.dashboard-number {

    font-size: 28px;

    font-weight: bold;

    color: #222;

}


.dashboard-unit {

    font-size: 14px;

    color: #777;

    margin-left: 3px;
}


.dashboard-link {

    display: inline-block;

    margin-top: 15px;

    text-decoration: none;

    color: #0d6efd;

    font-size: 13px;

    font-weight: bold;
}


.dashboard-link:hover {

    text-decoration: underline;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 1000px) {

    .dashboard-stats {

        grid-template-columns:
            repeat(2, 1fr);
    }

}


@media (max-width: 600px) {

    .dashboard-stats {

        grid-template-columns: 1fr;
    }

}

</style>


<!-- =========================
     BIENVENUE
========================= -->

<div class="welcome-box">

    <h1>
        👋 Bienvenue dans votre espace de gestion
    </h1>

    <p>
        Gérez facilement vos clients, leurs épargnes,
        les crédits accordés et les remboursements.
    </p>

    <div class="welcome-date">

        📅 Nous sommes le
        <?= e($dateActuelle) ?>

    </div>

</div>


<!-- =========================
     TITRE
========================= -->

<div class="dashboard-title">

    <h2>
        Tableau de bord
    </h2>

    <p>
        Vue générale de votre activité.
    </p>

</div>


<!-- =========================
     STATISTIQUES
========================= -->

<div class="dashboard-stats">


    <!-- CLIENTS -->

    <div class="dashboard-card">

        <div class="dashboard-icon">
            👥
        </div>

        <h3>
            Clients
        </h3>

        <div class="dashboard-number">
            <?= e($totalClients) ?>
        </div>

        <a
            href="client.php"
            class="dashboard-link"
        >
            Voir les clients →
        </a>

    </div>


    <!-- COMPTES EPARGNE -->

    <div class="dashboard-card">

        <div class="dashboard-icon">
            💰
        </div>

        <h3>
            Comptes d'épargne
        </h3>

        <div class="dashboard-number">
            <?= e($totalComptes) ?>
        </div>

        <a
            href="epargne.php"
            class="dashboard-link"
        >
            Gérer l'épargne →
        </a>

    </div>


    <!-- EPARGNE -->

    <div class="dashboard-card">

        <div class="dashboard-icon">
            💵
        </div>

        <h3>
            Épargne totale
        </h3>

        <div class="dashboard-number">

            <?= number_format(
                (float) $totalEpargne,
                2,
                ",",
                " "
            ) ?>

            <span class="dashboard-unit">
                $
            </span>

        </div>

        <a
            href="epargne.php"
            class="dashboard-link"
        >
            Voir l'épargne →
        </a>

    </div>


    <!-- CREDITS -->

    <div class="dashboard-card">

        <div class="dashboard-icon">
            💳
        </div>

        <h3>
            Crédits
        </h3>

        <div class="dashboard-number">
            <?= e($totalCredits) ?>
        </div>

        <a
            href="credits.php"
            class="dashboard-link"
        >
            Gérer les crédits →
        </a>

    </div>


    <!-- CREDITS ACCORDES -->

    <div class="dashboard-card">

        <div class="dashboard-icon">
            📊
        </div>

        <h3>
            Montant des crédits accordés
        </h3>

        <div class="dashboard-number">

            <?= number_format(
                (float) $totalCreditsAccordes,
                2,
                ",",
                " "
            ) ?>

            <span class="dashboard-unit">
                $
            </span>

        </div>

        <a
            href="credits.php"
            class="dashboard-link"
        >
            Voir les crédits →
        </a>

    </div>


    <!-- REMBOURSEMENTS -->

    <div class="dashboard-card">

        <div class="dashboard-icon">
            💸
        </div>

        <h3>
            Total remboursé
        </h3>

        <div class="dashboard-number">

            <?= number_format(
                (float) $totalRembourse,
                2,
                ",",
                " "
            ) ?>

            <span class="dashboard-unit">
                $
            </span>

        </div>

        <a
            href="remboursement.php"
            class="dashboard-link"
        >
            Voir les remboursements →
        </a>

    </div>


</div>


<?php

/*
|--------------------------------------------------------------------------
| FOOTER
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/layout/footer.php";

?>