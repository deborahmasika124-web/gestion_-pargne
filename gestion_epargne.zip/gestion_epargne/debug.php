<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

echo "<h1>PHP fonctionne</h1>";

require_once __DIR__ . "/config/database.php";

echo "<p>database.php chargé.</p>";

$database = new Database();

echo "<p>Classe Database trouvée.</p>";

$db = $database->connect();

echo "<p>Connexion MySQL réussie.</p>";

echo "<p>Base : gestion_epargne</p>";