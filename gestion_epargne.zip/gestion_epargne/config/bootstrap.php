<?php

session_start();

require_once __DIR__ . "/database.php";

$database = new Database();

$db = $database->connect();


function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        "UTF-8"
    );
}


function requireLogin(): void
{
    if (!isset($_SESSION["user_id"])) {

        header("Location: login.php");

        exit;
    }
}


function flash(string $type, string $message): void
{
    $_SESSION["flash"] = [
        "type" => $type,
        "message" => $message
    ];
}


function getFlash(): ?array
{
    if (!isset($_SESSION["flash"])) {
        return null;
    }

    $flash = $_SESSION["flash"];

    unset($_SESSION["flash"]);

    return $flash;
}