<?php

class User
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Connexion d'un utilisateur
     */
    public function login(string $email, string $motDePasse): ?array
    {
        $sql = "
            SELECT
                id,
                nom,
                email,
                mot_de_passe,
                role,
                created_at
            FROM users
            WHERE email = ?
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$email]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            return null;
        }

        if (!password_verify($motDePasse, $user["mot_de_passe"])) {
            return null;
        }

        return $user;
    }

    /**
     * Vérifier si un email existe déjà
     */
    public function emailExiste(string $email): bool
    {
        $sql = "
            SELECT id
            FROM users
            WHERE email = ?
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$email]);

        return $stmt->fetch() !== false;
    }

    /**
     * Créer un utilisateur
     */
    public function creer(
        string $nom,
        string $email,
        string $motDePasse,
        string $role = "agent"
    ): bool {

        if ($this->emailExiste($email)) {
            return false;
        }

        $hash = password_hash(
            $motDePasse,
            PASSWORD_DEFAULT
        );

        $sql = "
            INSERT INTO users
            (
                nom,
                email,
                mot_de_passe,
                role
            )
            VALUES (?, ?, ?, ?)
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $nom,
            $email,
            $hash,
            $role
        ]);
    }

    /**
     * Récupérer tous les utilisateurs
     */
    public function tous(): array
    {
        $sql = "
            SELECT
                id,
                nom,
                email,
                role,
                created_at
            FROM users
            ORDER BY id DESC
        ";

        $stmt = $this->db->query($sql);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Trouver un utilisateur par son ID
     */
    public function trouver(int $id): ?array
    {
        $sql = "
            SELECT
                id,
                nom,
                email,
                role,
                created_at
            FROM users
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        return $user ?: null;
    }
}