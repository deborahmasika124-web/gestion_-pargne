<?php

class Client
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Ajouter un client
     */
    public function ajouter(
        string $numero,
        string $nom,
        string $postnom,
        string $prenom,
        string $telephone,
        string $adresse,
        string $activite
    ): bool {

        $sql = "
            INSERT INTO clients
            (
                numero_client,
                nom,
                postnom,
                prenom,
                telephone,
                adresse,
                activite
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $numero,
            $nom,
            $postnom,
            $prenom,
            $telephone,
            $adresse,
            $activite
        ]);
    }

    /**
     * Modifier un client
     */
    public function modifier(
        int $id,
        string $nom,
        string $postnom,
        string $prenom,
        string $telephone,
        string $adresse,
        string $activite
    ): bool {

        $sql = "
            UPDATE clients
            SET
                nom = ?,
                postnom = ?,
                prenom = ?,
                telephone = ?,
                adresse = ?,
                activite = ?
            WHERE id = ?
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $nom,
            $postnom,
            $prenom,
            $telephone,
            $adresse,
            $activite,
            $id
        ]);
    }

    /**
     * Supprimer un client
     */
    public function supprimer(int $id): bool
    {
        $sql = "
            DELETE FROM clients
            WHERE id = ?
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([$id]);
    }

    /**
     * Trouver un client par son ID
     */
    public function trouver(int $id): ?array
    {
        $sql = "
            SELECT *
            FROM clients
            WHERE id = ?
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);

        $client = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($client === false) {
            return null;
        }

        return $client;
    }

    /**
     * Récupérer tous les clients
     */
    public function tous(): array
    {
        $sql = "
            SELECT *
            FROM clients
            ORDER BY id DESC
        ";

        $stmt = $this->db->query($sql);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Rechercher des clients
     */
    public function rechercher(string $recherche): array
    {
        $sql = "
            SELECT *
            FROM clients
            WHERE
                numero_client LIKE ?
                OR nom LIKE ?
                OR postnom LIKE ?
                OR prenom LIKE ?
                OR telephone LIKE ?
                OR activite LIKE ?
            ORDER BY id DESC
        ";

        $mot = "%" . $recherche . "%";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            $mot,
            $mot,
            $mot,
            $mot,
            $mot,
            $mot
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Récupérer la liste simplifiée des clients
     */
    public function clients(): array
    {
        $sql = "
            SELECT
                id,
                numero_client,
                nom,
                postnom,
                prenom,
                telephone
            FROM clients
            ORDER BY id DESC
        ";

        $stmt = $this->db->query($sql);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}