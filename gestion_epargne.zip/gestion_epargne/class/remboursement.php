<?php

class Remboursement
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function enregistrer(
        int $creditId,
        float $montant,
        string $date,
        string $observation,
        int $userId
    ): bool {

        if ($montant <= 0) {
            throw new Exception(
                "Montant invalide."
            );
        }

        $this->db->beginTransaction();

        try {

            $stmt = $this->db->prepare(
                "SELECT *
                 FROM credits
                 WHERE id = ?
                 FOR UPDATE"
            );

            $stmt->execute([
                $creditId
            ]);

            $credit = $stmt->fetch();

            if (!$credit) {
                throw new Exception(
                    "Crédit introuvable."
                );
            }

            if (
                !in_array(
                    $credit["statut"],
                    ["approuve", "en_cours"],
                    true
                )
            ) {
                throw new Exception(
                    "Ce crédit ne peut pas être remboursé."
                );
            }

            if (
                $montant >
                (float)$credit["solde_restant"]
            ) {
                $montant =
                    (float)$credit["solde_restant"];
            }

            $rembourse =
                (float)$credit["montant_rembourse"]
                + $montant;

            $reste =
                (float)$credit["solde_restant"]
                - $montant;

            $statut =
                $reste <= 0
                ? "termine"
                : "en_cours";

            $stmt = $this->db->prepare(
                "INSERT INTO remboursements
                (
                    credit_id,
                    montant,
                    date_remboursement,
                    observation,
                    user_id
                )
                VALUES (?, ?, ?, ?, ?)"
            );

            $stmt->execute([
                $creditId,
                $montant,
                $date,
                $observation,
                $userId
            ]);

            $stmt = $this->db->prepare(
                "UPDATE credits
                 SET
                    montant_rembourse = ?,
                    solde_restant = ?,
                    statut = ?
                 WHERE id = ?"
            );

            $stmt->execute([
                $rembourse,
                $reste,
                $statut,
                $creditId
            ]);

            $this->db->commit();

            return true;

        } catch (Throwable $e) {

            $this->db->rollBack();

            throw $e;
        }
    }
}