<?php

class Epargne
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Liste des comptes d'épargne
     */
    public function tous(): array
    {
        $sql = "
            SELECT
                ce.*,
                c.nom,
                c.postnom,
                c.prenom,
                c.telephone
            FROM comptes_epargne ce
            INNER JOIN clients c
                ON c.id = ce.client_id
            ORDER BY ce.id DESC
        ";

        $stmt = $this->db->query($sql);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Liste des clients
     */
    public function clients(): array
    {
        $sql = "
            SELECT *
            FROM clients
            ORDER BY nom ASC, postnom ASC
        ";

        return $this->db
            ->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Trouver un compte
     */
    public function trouver(int $id): ?array
    {
        $sql = "
            SELECT
                ce.*,
                c.nom,
                c.postnom,
                c.prenom,
                c.telephone
            FROM comptes_epargne ce
            INNER JOIN clients c
                ON c.id = ce.client_id
            WHERE ce.id = ?
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);

        $compte = $stmt->fetch(PDO::FETCH_ASSOC);

        return $compte ?: null;
    }

    /**
     * Ouvrir un compte
     */
    public function ouvrir(int $clientId): bool
    {
        $numero = "EP-" . date("YmdHis") . "-" . rand(10, 99);

        $sql = "
            INSERT INTO comptes_epargne
            (
                client_id,
                numero_compte,
                solde,
                date_ouverture,
                statut
            )
            VALUES (?, ?, 0.00, CURDATE(), 'actif')
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $clientId,
            $numero
        ]);
    }

    /**
     * Déposer de l'argent
     */
    public function depot(
        int $compteId,
        float $montant,
        string $description,
        ?int $userId = null
    ): bool {

        if ($montant <= 0) {
            return false;
        }

        try {

            $this->db->beginTransaction();

            /*
             * Vérifier le compte
             */
            $sql = "
                SELECT solde, statut
                FROM comptes_epargne
                WHERE id = ?
                FOR UPDATE
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$compteId]);

            $compte = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$compte || $compte["statut"] !== "actif") {
                $this->db->rollBack();
                return false;
            }

            /*
             * Augmenter le solde
             */
            $sql = "
                UPDATE comptes_epargne
                SET solde = solde + ?
                WHERE id = ?
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $montant,
                $compteId
            ]);

            /*
             * Enregistrer la transaction
             */
            $sql = "
                INSERT INTO transactions
                (
                    compte_id,
                    type,
                    montant,
                    description,
                    user_id
                )
                VALUES (?, 'depot', ?, ?, ?)
            ";

            $stmt = $this->db->prepare($sql);

            $stmt->execute([
                $compteId,
                $montant,
                $description,
                $userId
            ]);

            $this->db->commit();

            return true;

        } catch (PDOException $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /**
     * Retirer de l'argent
     */
    public function retrait(
        int $compteId,
        float $montant,
        string $description,
        ?int $userId = null
    ): bool {

        if ($montant <= 0) {
            return false;
        }

        try {

            $this->db->beginTransaction();

            /*
             * Vérifier le solde
             */
            $sql = "
                SELECT solde, statut
                FROM comptes_epargne
                WHERE id = ?
                FOR UPDATE
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$compteId]);

            $compte = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$compte || $compte["statut"] !== "actif") {
                $this->db->rollBack();
                return false;
            }

            if ((float) $compte["solde"] < $montant) {
                $this->db->rollBack();
                return false;
            }

            /*
             * Diminuer le solde
             */
            $sql = "
                UPDATE comptes_epargne
                SET solde = solde - ?
                WHERE id = ?
            ";

            $stmt = $this->db->prepare($sql);

            $stmt->execute([
                $montant,
                $compteId
            ]);

            /*
             * Enregistrer la transaction
             */
            $sql = "
                INSERT INTO transactions
                (
                    compte_id,
                    type,
                    montant,
                    description,
                    user_id
                )
                VALUES (?, 'retrait', ?, ?, ?)
            ";

            $stmt = $this->db->prepare($sql);

            $stmt->execute([
                $compteId,
                $montant,
                $description,
                $userId
            ]);

            $this->db->commit();

            return true;

        } catch (PDOException $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /**
     * Historique des transactions
     */
    public function transactions(?int $compteId = null): array
    {
        if ($compteId !== null) {

            $sql = "
                SELECT
                    t.*,
                    ce.numero_compte,
                    c.nom,
                    c.postnom,
                    c.prenom
                FROM transactions t
                INNER JOIN comptes_epargne ce
                    ON ce.id = t.compte_id
                INNER JOIN clients c
                    ON c.id = ce.client_id
                WHERE t.compte_id = ?
                ORDER BY t.id DESC
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([$compteId]);

        } else {

            $sql = "
                SELECT
                    t.*,
                    ce.numero_compte,
                    c.nom,
                    c.postnom,
                    c.prenom
                FROM transactions t
                INNER JOIN comptes_epargne ce
                    ON ce.id = t.compte_id
                INNER JOIN clients c
                    ON c.id = ce.client_id
                ORDER BY t.id DESC
            ";

            $stmt = $this->db->query($sql);
        }

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}