<?php

class Credit
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function demander(
        int $clientId,
        float $montant,
        float $taux,
        int $duree
    ): bool {

        if ($montant <= 0) {
            throw new Exception(
                "Montant invalide."
            );
        }

        if ($duree <= 0) {
            throw new Exception(
                "Durée invalide."
            );
        }

        $interet =
            $montant * ($taux / 100);

        $total =
            $montant + $interet;

        $journalier =
            $total / $duree;

        $stmt = $this->db->prepare(
            "INSERT INTO credits
            (
                client_id,
                montant,
                taux,
                duree,
                montant_total,
                montant_journalier,
                solde_restant,
                date_demande
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE())"
        );

        return $stmt->execute([
            $clientId,
            $montant,
            $taux,
            $duree,
            $total,
            $journalier,
            $total
        ]);
    }

    public function approuver(
        int $creditId
    ): bool {

        $stmt = $this->db->prepare(
            "UPDATE credits
             SET
                statut = 'approuve',
                date_decaissement = CURDATE()
             WHERE id = ?"
        );

        return $stmt->execute([
            $creditId
        ]);
    }

    public function rejeter(
        int $creditId
    ): bool {

        $stmt = $this->db->prepare(
            "UPDATE credits
             SET statut = 'rejete'
             WHERE id = ?"
        );

        return $stmt->execute([
            $creditId
        ]);
    }

    public function tous(): array
    {
        $stmt = $this->db->query(
            "SELECT
                credits.*,
                clients.numero_client,
                clients.nom,
                clients.postnom,
                clients.prenom
             FROM credits
             INNER JOIN clients
                ON clients.id = credits.client_id
             ORDER BY credits.id DESC"
        );

        return $stmt->fetchAll();
    }
}