<?php

error_reporting(E_ALL);
ini_set("display_errors", "1");

require_once __DIR__ . "/config/bootstrap.php";

requireLogin();


/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$message = "";
$typeMessage = "";


/*
|--------------------------------------------------------------------------
| TRAITEMENT DES FORMULAIRES
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";


    /*
    |--------------------------------------------------------------------------
    | OUVRIR UN COMPTE
    |--------------------------------------------------------------------------
    */

    if ($action === "ouvrir_compte") {

        $clientId = (int) ($_POST["client_id"] ?? 0);

        if ($clientId <= 0) {

            $message = "Veuillez sélectionner un client.";
            $typeMessage = "error";

        } else {

            try {

                $stmt = $db->prepare("
                    SELECT id, nom, postnom, prenom
                    FROM clients
                    WHERE id = ?
                    LIMIT 1
                ");

                $stmt->execute([$clientId]);

                $client = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$client) {

                    $message = "Client introuvable.";
                    $typeMessage = "error";

                } else {

                    /*
                    |--------------------------------------------------------------------------
                    | Vérifier si le client possède déjà un compte
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $db->prepare("
                        SELECT id
                        FROM comptes_epargne
                        WHERE client_id = ?
                        LIMIT 1
                    ");

                    $stmt->execute([$clientId]);

                    $compteExiste = $stmt->fetch();

                    if ($compteExiste) {

                        $message =
                            "Ce client possède déjà un compte d'épargne.";

                        $typeMessage = "error";

                    } else {

                        /*
                        |--------------------------------------------------------------------------
                        | Génération du numéro de compte
                        |--------------------------------------------------------------------------
                        */

                        $numeroCompte =
                            "EP-"
                            . date("Ymd")
                            . "-"
                            . str_pad(
                                (string) $clientId,
                                4,
                                "0",
                                STR_PAD_LEFT
                            );


                        /*
                        |--------------------------------------------------------------------------
                        | Vérifier que le numéro n'existe pas
                        |--------------------------------------------------------------------------
                        */

                        $stmt = $db->prepare("
                            SELECT id
                            FROM comptes_epargne
                            WHERE numero_compte = ?
                            LIMIT 1
                        ");

                        $stmt->execute([$numeroCompte]);

                        if ($stmt->fetch()) {

                            $numeroCompte =
                                "EP-"
                                . date("YmdHis")
                                . "-"
                                . $clientId;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Création du compte
                        |--------------------------------------------------------------------------
                        */

                        $stmt = $db->prepare("
                            INSERT INTO comptes_epargne
                            (
                                client_id,
                                numero_compte,
                                solde,
                                date_ouverture,
                                statut
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                0.00,
                                CURDATE(),
                                'actif'
                            )
                        ");

                        $stmt->execute([
                            $clientId,
                            $numeroCompte
                        ]);


                        $message =
                            "Compte d'épargne ouvert avec succès. "
                            . "Numéro : "
                            . $numeroCompte;

                        $typeMessage = "success";
                    }
                }

            } catch (PDOException $e) {

                $message =
                    "Erreur lors de l'ouverture du compte : "
                    . $e->getMessage();

                $typeMessage = "error";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | DÉPÔT
    |--------------------------------------------------------------------------
    */

    if ($action === "depot") {

        $compteId = (int) ($_POST["compte_id"] ?? 0);
        $montant = (float) ($_POST["montant"] ?? 0);
        $description = trim($_POST["description"] ?? "");


        if ($compteId <= 0) {

            $message = "Veuillez sélectionner un compte.";
            $typeMessage = "error";

        } elseif ($montant <= 0) {

            $message =
                "Le montant du dépôt doit être supérieur à zéro.";

            $typeMessage = "error";

        } else {

            try {

                $db->beginTransaction();


                /*
                |--------------------------------------------------------------------------
                | Récupérer le compte
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    SELECT
                        id,
                        solde,
                        statut
                    FROM comptes_epargne
                    WHERE id = ?
                    FOR UPDATE
                ");

                $stmt->execute([$compteId]);

                $compte = $stmt->fetch(PDO::FETCH_ASSOC);


                if (!$compte) {

                    throw new Exception(
                        "Compte introuvable."
                    );
                }


                if ($compte["statut"] !== "actif") {

                    throw new Exception(
                        "Ce compte n'est pas actif."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Ancien solde
                |--------------------------------------------------------------------------
                */

                $soldeAvant = (float) $compte["solde"];


                /*
                |--------------------------------------------------------------------------
                | Nouveau solde
                |--------------------------------------------------------------------------
                */

                $nouveauSolde =
                    $soldeAvant + $montant;


                /*
                |--------------------------------------------------------------------------
                | Mise à jour du solde
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    UPDATE comptes_epargne
                    SET solde = ?
                    WHERE id = ?
                ");

                $stmt->execute([
                    $nouveauSolde,
                    $compteId
                ]);


                /*
                |--------------------------------------------------------------------------
                | Enregistrer la transaction
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    INSERT INTO transactions
                    (
                        compte_id,
                        type,
                        montant,
                        description,
                        date_transaction,
                        user_id
                    )
                    VALUES
                    (
                        ?,
                        'depot',
                        ?,
                        ?,
                        NOW(),
                        ?
                    )
                ");


                $userId =
                    $_SESSION["user_id"] ?? null;


                $descriptionFinale =
                    $description !== ""
                        ? $description
                        : "Dépôt d'épargne";


                $stmt->execute([
                    $compteId,
                    $montant,
                    $descriptionFinale,
                    $userId
                ]);


                $db->commit();


                /*
                |--------------------------------------------------------------------------
                | Message avec solde restant
                |--------------------------------------------------------------------------
                */

                $message =
                    "Dépôt effectué avec succès : "
                    . number_format(
                        $montant,
                        2,
                        ",",
                        " "
                    )
                    . " $. "
                    . "Nouveau solde : "
                    . number_format(
                        $nouveauSolde,
                        2,
                        ",",
                        " "
                    )
                    . " $";


                $typeMessage = "success";


            } catch (Throwable $e) {

                if ($db->inTransaction()) {
                    $db->rollBack();
                }


                $message =
                    "Erreur lors du dépôt : "
                    . $e->getMessage();

                $typeMessage = "error";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | RETRAIT
    |--------------------------------------------------------------------------
    */

    if ($action === "retrait") {

        $compteId = (int) ($_POST["compte_id"] ?? 0);
        $montant = (float) ($_POST["montant"] ?? 0);
        $description = trim($_POST["description"] ?? "");


        if ($compteId <= 0) {

            $message =
                "Veuillez sélectionner un compte.";

            $typeMessage = "error";

        } elseif ($montant <= 0) {

            $message =
                "Le montant du retrait doit être supérieur à zéro.";

            $typeMessage = "error";

        } else {

            try {

                $db->beginTransaction();


                /*
                |--------------------------------------------------------------------------
                | Récupérer le compte
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    SELECT
                        id,
                        solde,
                        statut
                    FROM comptes_epargne
                    WHERE id = ?
                    FOR UPDATE
                ");

                $stmt->execute([$compteId]);

                $compte =
                    $stmt->fetch(PDO::FETCH_ASSOC);


                if (!$compte) {

                    throw new Exception(
                        "Compte introuvable."
                    );
                }


                if ($compte["statut"] !== "actif") {

                    throw new Exception(
                        "Ce compte n'est pas actif."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Solde avant retrait
                |--------------------------------------------------------------------------
                */

                $soldeAvant =
                    (float) $compte["solde"];


                /*
                |--------------------------------------------------------------------------
                | Vérifier le solde disponible
                |--------------------------------------------------------------------------
                */

                if ($montant > $soldeAvant) {

                    throw new Exception(
                        "Solde insuffisant. "
                        . "Solde disponible : "
                        . number_format(
                            $soldeAvant,
                            2,
                            ",",
                            " "
                        )
                        . " $"
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | CALCUL DU SOLDE RESTANT
                |--------------------------------------------------------------------------
                */

                $soldeRestant =
                    $soldeAvant - $montant;


                /*
                |--------------------------------------------------------------------------
                | Éviter les petits problèmes de décimales
                |--------------------------------------------------------------------------
                */

                if (abs($soldeRestant) < 0.000001) {
                    $soldeRestant = 0.00;
                }


                /*
                |--------------------------------------------------------------------------
                | Mise à jour du compte
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    UPDATE comptes_epargne
                    SET solde = ?
                    WHERE id = ?
                ");

                $stmt->execute([
                    $soldeRestant,
                    $compteId
                ]);


                /*
                |--------------------------------------------------------------------------
                | Enregistrer le retrait
                |--------------------------------------------------------------------------
                */

                $stmt = $db->prepare("
                    INSERT INTO transactions
                    (
                        compte_id,
                        type,
                        montant,
                        description,
                        date_transaction,
                        user_id
                    )
                    VALUES
                    (
                        ?,
                        'retrait',
                        ?,
                        ?,
                        NOW(),
                        ?
                    )
                ");


                $userId =
                    $_SESSION["user_id"] ?? null;


                $descriptionFinale =
                    $description !== ""
                        ? $description
                        : "Retrait d'épargne";


                $stmt->execute([
                    $compteId,
                    $montant,
                    $descriptionFinale,
                    $userId
                ]);


                $db->commit();


                /*
                |--------------------------------------------------------------------------
                | MESSAGE AVEC SOLDE RESTANT
                |--------------------------------------------------------------------------
                */

                $message =
                    "Retrait effectué avec succès : "
                    . number_format(
                        $montant,
                        2,
                        ",",
                        " "
                    )
                    . " $. "
                    . "Solde restant : "
                    . number_format(
                        $soldeRestant,
                        2,
                        ",",
                        " "
                    )
                    . " $";


                $typeMessage = "success";


            } catch (Throwable $e) {

                if ($db->inTransaction()) {
                    $db->rollBack();
                }


                $message =
                    "Erreur lors du retrait : "
                    . $e->getMessage();

                $typeMessage = "error";
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| CHARGER LES CLIENTS
|--------------------------------------------------------------------------
*/

$clients = [];

try {

    $stmt = $db->query("
        SELECT
            id,
            numero_client,
            nom,
            postnom,
            prenom,
            telephone
        FROM clients
        ORDER BY id DESC
    ");

    $clients =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    $message =
        "Erreur clients : "
        . $e->getMessage();

    $typeMessage = "error";
}


/*
|--------------------------------------------------------------------------
| CHARGER LES COMPTES
|--------------------------------------------------------------------------
*/

$comptes = [];

try {

    $stmt = $db->query("
        SELECT
            ce.id,
            ce.client_id,
            ce.numero_compte,
            ce.solde,
            ce.date_ouverture,
            ce.statut,

            c.numero_client,
            c.nom,
            c.postnom,
            c.prenom,
            c.telephone

        FROM comptes_epargne ce

        INNER JOIN clients c
            ON c.id = ce.client_id

        ORDER BY ce.id DESC
    ");

    $comptes =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    $message =
        "Erreur comptes : "
        . $e->getMessage();

    $typeMessage = "error";
}


/*
|--------------------------------------------------------------------------
| STATISTIQUES
|--------------------------------------------------------------------------
*/

$nombreComptes =
    count($comptes);


$soldeTotal = 0;


foreach ($comptes as $compte) {

    $soldeTotal +=
        (float) $compte["solde"];
}


/*
|--------------------------------------------------------------------------
| NOMBRE DE TRANSACTIONS
|--------------------------------------------------------------------------
*/

$nombreTransactions = 0;

try {

    $stmt = $db->query("
        SELECT COUNT(*) AS total
        FROM transactions
    ");

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    $nombreTransactions =
        (int) $row["total"];

} catch (PDOException $e) {

    $nombreTransactions = 0;
}


/*
|--------------------------------------------------------------------------
| DERNIÈRES TRANSACTIONS
|--------------------------------------------------------------------------
*/

$transactions = [];

try {

    $stmt = $db->query("
        SELECT
            t.id,
            t.type,
            t.montant,
            t.description,
            t.date_transaction,

            ce.numero_compte,

            c.nom,
            c.postnom,
            c.prenom

        FROM transactions t

        INNER JOIN comptes_epargne ce
            ON ce.id = t.compte_id

        INNER JOIN clients c
            ON c.id = ce.client_id

        ORDER BY t.id DESC

        LIMIT 10
    ");

    $transactions =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    $transactions = [];
}

?>


<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Gestion de l'épargne</title>


    <style>

        * {
            box-sizing: border-box;
        }


        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #172033;
        }


        header {
            background: #2453d4;
            color: white;
            padding: 18px 30px;

            display: flex;
            justify-content: space-between;
            align-items: center;
        }


        header h1 {
            margin: 0;
            font-size: 26px;
        }


        header .user {
            text-align: right;
        }


        nav {
            background: white;
            border-bottom: 1px solid #ddd;
            padding: 16px 30px;
        }


        nav a {
            color: #172033;
            text-decoration: none;
            margin-right: 25px;
            font-size: 15px;
        }


        nav a:hover {
            color: #2453d4;
        }


        nav a.logout {
            float: right;
            color: #dc2626;
        }


        .container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
        }


        h2 {
            margin-bottom: 8px;
        }


        .subtitle {
            color: #667085;
            margin-bottom: 25px;
        }


        .alert {
            padding: 14px 18px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }


        .alert.success {
            background: #dcfce7;
            color: #166534;
        }


        .alert.error {
            background: #fee2e2;
            color: #991b1b;
        }


        .stats {
            display: grid;
            grid-template-columns:
                repeat(3, 1fr);

            gap: 20px;
            margin-bottom: 25px;
        }


        .stat {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow:
                0 3px 12px rgba(0,0,0,.06);
        }


        .stat-title {
            color: #667085;
            margin-bottom: 10px;
        }


        .stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #2453d4;
        }


        .grid {
            display: grid;
            grid-template-columns:
                repeat(2, 1fr);

            gap: 20px;
        }


        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow:
                0 3px 12px rgba(0,0,0,.06);

            margin-bottom: 25px;
        }


        .card h3 {
            margin-top: 0;
            margin-bottom: 20px;
        }


        label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }


        select,
        input,
        textarea {
            width: 100%;
            padding: 12px;

            border: 1px solid #ccd2dc;
            border-radius: 7px;

            font-size: 15px;

            margin-bottom: 15px;
        }


        textarea {
            min-height: 80px;
            resize: vertical;
        }


        button {
            border: none;
            border-radius: 7px;

            padding: 12px 20px;

            font-size: 15px;
            font-weight: bold;

            cursor: pointer;
        }


        .btn-primary {
            background: #2453d4;
            color: white;
        }


        .btn-success {
            background: #16a34a;
            color: white;
        }


        .btn-danger {
            background: #dc2626;
            color: white;
        }


        .btn-primary:hover,
        .btn-success:hover,
        .btn-danger:hover {
            opacity: .9;
        }


        .account-list {
            overflow-x: auto;
        }


        table {
            width: 100%;
            border-collapse: collapse;
        }


        th,
        td {
            padding: 13px;
            border-bottom: 1px solid #e5e7eb;
            text-align: left;
        }


        th {
            background: #f8fafc;
        }


        .badge {
            display: inline-block;

            padding: 5px 9px;

            border-radius: 20px;

            font-size: 12px;
            font-weight: bold;
        }


        .badge-active {
            background: #dcfce7;
            color: #166534;
        }


        .badge-depot {
            background: #dcfce7;
            color: #166534;
        }


        .badge-retrait {
            background: #fee2e2;
            color: #991b1b;
        }


        .amount {
            font-weight: bold;
        }


        .solde-restant {
            color: #2453d4;
            font-weight: bold;
        }


        .solde-zero {
            color: #dc2626;
            font-weight: bold;
        }


        @media (max-width: 800px) {

            .stats,
            .grid {
                grid-template-columns: 1fr;
            }


            header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }


            nav {
                line-height: 2;
            }


            nav a.logout {
                float: none;
            }


            .container {
                width: 94%;
            }
        }

    </style>

</head>


<body>


<header>

    <h1>
        Gestion Épargne
    </h1>


    <div class="user">

        <?php

        $nomUtilisateur =
            $_SESSION["user"]["nom"]
            ?? $_SESSION["user_name"]
            ?? $_SESSION["user_nom"]
            ?? "Administrateur";


        $role =
            $_SESSION["user"]["role"]
            ?? $_SESSION["user_role"]
            ?? "admin";

        ?>


        <strong>
            <?= htmlspecialchars(
                $nomUtilisateur,
                ENT_QUOTES,
                "UTF-8"
            ) ?>
        </strong>

        <br>

        <small>
            <?= htmlspecialchars(
                $role,
                ENT_QUOTES,
                "UTF-8"
            ) ?>
        </small>

    </div>

</header>


<nav>

    <a href="dashboard.php">
        Tableau de bord
    </a>


    <a href="client.php">
        Clients
    </a>


    <a href="epargne.php">
        Épargne
    </a>


    <a href="credits.php">
        Crédits
    </a>


    <a href="remboursement.php">
        Remboursements
    </a>


    <a href="transactions.php">
        Transactions
    </a>


    <a
        href="logout.php"
        class="logout"
    >
        Déconnexion
    </a>

</nav>


<main class="container">


    <h2>
        Gestion de l'épargne
    </h2>


    <p class="subtitle">
        Gérez les comptes d'épargne, les dépôts et les retraits.
    </p>


    <?php if ($message !== ""): ?>

        <div class="alert <?= $typeMessage ?>">

            <?= htmlspecialchars(
                $message,
                ENT_QUOTES,
                "UTF-8"
            ) ?>

        </div>

    <?php endif; ?>


    <!-- STATISTIQUES -->

    <div class="stats">


        <div class="stat">

            <div class="stat-title">
                Comptes d'épargne
            </div>

            <div class="stat-value">
                <?= $nombreComptes ?>
            </div>

        </div>


        <div class="stat">

            <div class="stat-title">
                Solde total
            </div>

            <div class="stat-value">

                <?= number_format(
                    $soldeTotal,
                    2,
                    ",",
                    " "
                ) ?>

                $

            </div>

        </div>


        <div class="stat">

            <div class="stat-title">
                Transactions
            </div>

            <div class="stat-value">
                <?= $nombreTransactions ?>
            </div>

        </div>


    </div>


    <!-- OUVERTURE COMPTE -->

    <div class="card">

        <h3>
            Ouvrir un compte d'épargne
        </h3>


        <form
            method="POST"
            action="epargne.php"
        >

            <input
                type="hidden"
                name="action"
                value="ouvrir_compte"
            >


            <label>
                Client *
            </label>


            <select
                name="client_id"
                required
            >

                <option value="">
                    -- Sélectionner un client --
                </option>


                <?php foreach ($clients as $client): ?>

                    <option
                        value="<?= (int) $client["id"] ?>"
                    >

                        <?= htmlspecialchars(
                            $client["nom"]
                            . " "
                            . $client["postnom"]
                            . " "
                            . $client["prenom"],
                            ENT_QUOTES,
                            "UTF-8"
                        ) ?>

                        -

                        <?= htmlspecialchars(
                            $client["telephone"],
                            ENT_QUOTES,
                            "UTF-8"
                        ) ?>

                    </option>

                <?php endforeach; ?>

            </select>


            <?php if (count($clients) === 0): ?>

                <p style="color:#dc2626;">
                    Aucun client enregistré.
                    Ajoutez d'abord un client.
                </p>

            <?php endif; ?>


            <button
                type="submit"
                class="btn-primary"
                <?= count($clients) === 0
                    ? "disabled"
                    : "" ?>
            >

                + Ouvrir le compte

            </button>

        </form>

    </div>


    <!-- DEPOT / RETRAIT -->

    <div class="grid">


        <!-- DEPOT -->

        <div class="card">

            <h3>
                💰 Nouveau dépôt
            </h3>


            <form
                method="POST"
                action="epargne.php"
            >

                <input
                    type="hidden"
                    name="action"
                    value="depot"
                >


                <label>
                    Compte
                </label>


                <select
                    name="compte_id"
                    required
                >

                    <option value="">
                        -- Compte --
                    </option>


                    <?php foreach ($comptes as $compte): ?>

                        <option
                            value="<?= (int) $compte["id"] ?>"
                        >

                            <?= htmlspecialchars(
                                $compte["numero_compte"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>

                            -

                            <?= htmlspecialchars(
                                $compte["nom"]
                                . " "
                                . $compte["postnom"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>

                            -

                            Solde :

                            <?= number_format(
                                (float) $compte["solde"],
                                2,
                                ",",
                                " "
                            ) ?>

                            $

                        </option>

                    <?php endforeach; ?>

                </select>


                <label>
                    Montant
                </label>


                <input
                    type="number"
                    name="montant"
                    min="0.01"
                    step="0.01"
                    placeholder="Ex : 100"
                    required
                >


                <label>
                    Description
                </label>


                <textarea
                    name="description"
                    placeholder="Description du dépôt"
                ></textarea>


                <button
                    type="submit"
                    class="btn-success"
                >

                    💰 Effectuer le dépôt

                </button>

            </form>

        </div>


        <!-- RETRAIT -->

        <div class="card">

            <h3>
                💸 Nouveau retrait
            </h3>


            <form
                method="POST"
                action="epargne.php"
            >

                <input
                    type="hidden"
                    name="action"
                    value="retrait"
                >


                <label>
                    Compte
                </label>


                <select
                    name="compte_id"
                    required
                >

                    <option value="">
                        -- Compte --
                    </option>


                    <?php foreach ($comptes as $compte): ?>

                        <option
                            value="<?= (int) $compte["id"] ?>"
                        >

                            <?= htmlspecialchars(
                                $compte["numero_compte"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>

                            -

                            <?= htmlspecialchars(
                                $compte["nom"]
                                . " "
                                . $compte["postnom"],
                                ENT_QUOTES,
                                "UTF-8"
                            ) ?>

                            -

                            Solde disponible :

                            <?= number_format(
                                (float) $compte["solde"],
                                2,
                                ",",
                                " "
                            ) ?>

                            $

                        </option>

                    <?php endforeach; ?>

                </select>


                <label>
                    Montant du retrait
                </label>


                <input
                    type="number"
                    name="montant"
                    min="0.01"
                    step="0.01"
                    placeholder="Ex : 50"
                    required
                >


                <label>
                    Description
                </label>


                <textarea
                    name="description"
                    placeholder="Description du retrait"
                ></textarea>


                <button
                    type="submit"
                    class="btn-danger"
                >

                    💸 Effectuer le retrait

                </button>

            </form>

        </div>


    </div>


    <!-- COMPTES -->

    <div class="card">

        <h3>
            Comptes d'épargne
        </h3>


        <div class="account-list">

            <table>

                <thead>

                    <tr>

                        <th>
                            Compte
                        </th>

                        <th>
                            Client
                        </th>

                        <th>
                            Téléphone
                        </th>

                        <th>
                            Solde actuel
                        </th>

                        <th>
                            Date
                        </th>

                        <th>
                            Statut
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php if (count($comptes) === 0): ?>

                    <tr>

                        <td
                            colspan="6"
                            style="text-align:center;"
                        >

                            Aucun compte d'épargne.

                        </td>

                    </tr>


                <?php else: ?>


                    <?php foreach ($comptes as $compte): ?>

                        <tr>

                            <td>

                                <strong>

                                    <?= htmlspecialchars(
                                        $compte["numero_compte"],
                                        ENT_QUOTES,
                                        "UTF-8"
                                    ) ?>

                                </strong>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $compte["nom"]
                                    . " "
                                    . $compte["postnom"]
                                    . " "
                                    . $compte["prenom"],
                                    ENT_QUOTES,
                                    "UTF-8"
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $compte["telephone"],
                                    ENT_QUOTES,
                                    "UTF-8"
                                ) ?>

                            </td>


                            <td class="amount">

                                <?php

                                $soldeAffiche =
                                    (float) $compte["solde"];

                                ?>

                                <span
                                    class="<?= $soldeAffiche > 0
                                        ? "solde-restant"
                                        : "solde-zero" ?>"
                                >

                                    <?= number_format(
                                        $soldeAffiche,
                                        2,
                                        ",",
                                        " "
                                    ) ?>

                                    $

                                </span>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $compte["date_ouverture"],
                                    ENT_QUOTES,
                                    "UTF-8"
                                ) ?>

                            </td>


                            <td>

                                <span
                                    class="badge badge-active"
                                >

                                    <?= htmlspecialchars(
                                        $compte["statut"],
                                        ENT_QUOTES,
                                        "UTF-8"
                                    ) ?>

                                </span>

                            </td>

                        </tr>


                    <?php endforeach; ?>


                <?php endif; ?>


                </tbody>

            </table>

        </div>

    </div>


    <!-- TRANSACTIONS -->

    <div class="card">

        <h3>
            Dernières transactions
        </h3>


        <div class="account-list">

            <table>

                <thead>

                    <tr>

                        <th>
                            Date
                        </th>

                        <th>
                            Compte
                        </th>

                        <th>
                            Client
                        </th>

                        <th>
                            Type
                        </th>

                        <th>
                            Montant
                        </th>

                        <th>
                            Solde après opération
                        </th>

                        <th>
                            Description
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php if (count($transactions) === 0): ?>

                    <tr>

                        <td
                            colspan="7"
                            style="text-align:center;"
                        >

                            Aucune transaction.

                        </td>

                    </tr>


                <?php else: ?>


                    <?php foreach ($transactions as $transaction): ?>

                        <?php

                        /*
                        |--------------------------------------------------------------------------
                        | Calcul du solde après cette transaction
                        |--------------------------------------------------------------------------
                        |
                        | On recalcule le solde en regardant toutes les
                        | transactions jusqu'à celle-ci.
                        |
                        */

                        $stmtSolde = $db->prepare("
                            SELECT
                                COALESCE(
                                    SUM(
                                        CASE
                                            WHEN type = 'depot'
                                            THEN montant
                                            WHEN type = 'retrait'
                                            THEN -montant
                                            ELSE 0
                                        END
                                    ),
                                    0
                                ) AS solde_apres
                            FROM transactions
                            WHERE compte_id = ?
                              AND id <= ?
                        ");

                        $stmtSolde->execute([
                            $transaction["numero_compte"],
                            $transaction["id"]
                        ]);

                        /*
                        |--------------------------------------------------------------------------
                        | Comme la requête ci-dessus utilise le numéro de compte,
                        | on récupère le vrai compte.
                        |--------------------------------------------------------------------------
                        */

                        $stmtCompteSolde = $db->prepare("
                            SELECT id
                            FROM comptes_epargne
                            WHERE numero_compte = ?
                            LIMIT 1
                        ");

                        $stmtCompteSolde->execute([
                            $transaction["numero_compte"]
                        ]);

                        $compteTransaction =
                            $stmtCompteSolde->fetch(
                                PDO::FETCH_ASSOC
                            );


                        $soldeApres = 0;


                        if ($compteTransaction) {

                            $stmtSolde = $db->prepare("
                                SELECT
                                    COALESCE(
                                        SUM(
                                            CASE
                                                WHEN type = 'depot'
                                                THEN montant
                                                WHEN type = 'retrait'
                                                THEN -montant
                                                ELSE 0
                                            END
                                        ),
                                        0
                                    ) AS solde_apres
                                FROM transactions
                                WHERE compte_id = ?
                                AND id <= ?
                            ");

                            $stmtSolde->execute([
                                $compteTransaction["id"],
                                $transaction["id"]
                            ]);

                            $soldeRow =
                                $stmtSolde->fetch(
                                    PDO::FETCH_ASSOC
                                );

                            $soldeApres =
                                (float) (
                                    $soldeRow["solde_apres"]
                                    ?? 0
                                );
                        }

                        ?>


                        <tr>

                            <td>

                                <?= htmlspecialchars(
                                    $transaction["date_transaction"],
                                    ENT_QUOTES,
                                    "UTF-8"
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $transaction["numero_compte"],
                                    ENT_QUOTES,
                                    "UTF-8"
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $transaction["nom"]
                                    . " "
                                    . $transaction["postnom"]
                                    . " "
                                    . $transaction["prenom"],
                                    ENT_QUOTES,
                                    "UTF-8"
                                ) ?>

                            </td>


                            <td>


                                <?php if (
                                    $transaction["type"]
                                    === "depot"
                                ): ?>


                                    <span
                                        class="badge badge-depot"
                                    >
                                        DÉPÔT
                                    </span>


                                <?php else: ?>


                                    <span
                                        class="badge badge-retrait"
                                    >
                                        RETRAIT
                                    </span>


                                <?php endif; ?>


                            </td>


                            <td class="amount">

                                <?= number_format(
                                    (float) $transaction["montant"],
                                    2,
                                    ",",
                                    " "
                                ) ?>

                                $

                            </td>


                            <td>

                                <strong
                                    class="<?= $soldeApres > 0
                                        ? "solde-restant"
                                        : "solde-zero" ?>"
                                >

                                    <?= number_format(
                                        $soldeApres,
                                        2,
                                        ",",
                                        " "
                                    ) ?>

                                    $

                                </strong>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $transaction["description"]
                                    ?? "",
                                    ENT_QUOTES,
                                    "UTF-8"
                                ) ?>

                            </td>

                        </tr>


                    <?php endforeach; ?>


                <?php endif; ?>


                </tbody>

            </table>

        </div>

    </div>


</main>


</body>

</html>